"""
Data models for extracted schema components from AST (Section 5.3.4).
"""
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Any


@dataclass
class ExtractedTable:
    """Represents a table referenced in the SQL AST."""
    name: str
    alias: Optional[str] = None
    schema: Optional[str] = None
    is_cte: bool = False
    is_subquery: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ExtractedColumn:
    """Represents a column referenced in the SQL AST."""
    name: str
    table_alias: Optional[str] = None
    table_name: Optional[str] = None
    clause: str = "SELECT"  # SELECT, WHERE, JOIN, GROUP_BY, ORDER_BY, HAVING
    is_wildcard: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ExtractedJoin:
    """Represents a table JOIN operation in the SQL AST."""
    left_table: Optional[str]
    right_table: str
    join_type: str = "INNER"
    condition_raw: Optional[str] = None
    left_column: Optional[str] = None
    right_column: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ExtractedCondition:
    """Represents a filter condition in WHERE, HAVING, or ON clauses."""
    clause_type: str  # WHERE, HAVING, ON
    raw_expression: str
    referenced_columns: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ExtractedElements:
    """Aggregates all schema elements extracted from the AST."""
    tables: List[ExtractedTable] = field(default_factory=list)
    columns: List[ExtractedColumn] = field(default_factory=list)
    joins: List[ExtractedJoin] = field(default_factory=list)
    aliases: Dict[str, str] = field(default_factory=dict)
    conditions: List[ExtractedCondition] = field(default_factory=list)
    ctes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tables": [t.to_dict() for t in self.tables],
            "columns": [c.to_dict() for c in self.columns],
            "joins": [j.to_dict() for j in self.joins],
            "aliases": self.aliases,
            "conditions": [cond.to_dict() for cond in self.conditions],
            "ctes": self.ctes
        }

    def get_physical_tables(self) -> List[str]:
        """Returns list of distinct physical table names excluding CTEs and subqueries."""
        seen = set()
        result = []
        for t in self.tables:
            if not t.is_cte and not t.is_subquery and t.name:
                low = t.name.lower()
                if low not in seen:
                    seen.add(low)
                    result.append(t.name)
        return result
