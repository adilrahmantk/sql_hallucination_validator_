"""
Schema Extraction Module (Section 5.3.4)
Traverses the AST to systematically extract tables, columns, joins, aliases, and conditions.
"""
from typing import List, Dict, Set, Optional
import sqlglot
from sqlglot import exp

from .models import (
    ExtractedTable,
    ExtractedColumn,
    ExtractedJoin,
    ExtractedCondition,
    ExtractedElements,
)
from ..parser.ast_parser import ASTParser


class SchemaExtractor:
    """Traverses SQL AST and extracts all schema footprint components."""

    @classmethod
    def extract(cls, ast_root: exp.Expression, dialect: str = "mysql") -> ExtractedElements:
        """
        Main extraction entrypoint.
        Extracts tables, columns, joins, aliases, and conditions from the given AST.
        """
        if ast_root is None:
            return ExtractedElements()

        ctes = list(ASTParser.get_cte_names(ast_root))
        alias_map = ASTParser.get_table_alias_map(ast_root)

        tables = cls._extract_tables(ast_root, ctes)
        joins = cls._extract_joins(ast_root, alias_map)
        columns = cls._extract_columns(ast_root, alias_map, ctes)
        conditions = cls._extract_conditions(ast_root)

        return ExtractedElements(
            tables=tables,
            columns=columns,
            joins=joins,
            aliases=alias_map,
            conditions=conditions,
            ctes=ctes,
        )

    @classmethod
    def _extract_tables(cls, ast_root: exp.Expression, ctes: List[str]) -> List[ExtractedTable]:
        """Extracts all table references from the AST."""
        cte_set = {c.lower() for c in ctes}
        tables: List[ExtractedTable] = []
        seen = set()

        for table_node in ast_root.find_all(exp.Table):
            table_name = table_node.name
            if not table_name:
                continue

            low_name = table_name.lower()
            table_alias = table_node.alias if table_node.alias else None
            schema_name = table_node.db if table_node.db else None
            is_cte = low_name in cte_set

            key = (low_name, table_alias.lower() if table_alias else None, schema_name)
            if key not in seen:
                seen.add(key)
                tables.append(
                    ExtractedTable(
                        name=table_name,
                        alias=table_alias,
                        schema=schema_name,
                        is_cte=is_cte,
                        is_subquery=False,
                    )
                )

        # Extract derived table / subquery aliases in FROM or JOIN
        for subquery in ast_root.find_all(exp.Subquery):
            if subquery.alias:
                tables.append(
                    ExtractedTable(
                        name=subquery.alias,
                        alias=subquery.alias,
                        schema=None,
                        is_cte=False,
                        is_subquery=True,
                    )
                )

        return tables

    @classmethod
    def _extract_columns(
        cls, ast_root: exp.Expression, alias_map: Dict[str, str], ctes: List[str]
    ) -> List[ExtractedColumn]:
        """
        Extracts all column references across SELECT, WHERE, JOIN ON, GROUP BY, ORDER BY, HAVING.
        Resolves table aliases to table names.
        """
        cte_set = {c.lower() for c in ctes}
        columns: List[ExtractedColumn] = []
        seen = set()

        def determine_clause(node: exp.Expression) -> str:
            """Finds which SQL clause the column node belongs to."""
            parent = node.parent
            while parent:
                if isinstance(parent, exp.Select):
                    return "SELECT"
                if isinstance(parent, exp.Where):
                    return "WHERE"
                if isinstance(parent, exp.Join):
                    return "JOIN"
                if isinstance(parent, exp.Group):
                    return "GROUP_BY"
                if isinstance(parent, exp.Order):
                    return "ORDER_BY"
                if isinstance(parent, exp.Having):
                    return "HAVING"
                parent = parent.parent
            return "SELECT"

        # 1. Standard Column nodes (e.g. c.customer_name, id, total)
        for col_node in ast_root.find_all(exp.Column):
            col_name = col_node.name
            if not col_name:
                continue

            table_alias = col_node.table if col_node.table else None
            resolved_table = None

            if table_alias:
                resolved_table = alias_map.get(table_alias.lower(), table_alias)
                # If resolved to a subquery marker, retain alias
                if resolved_table and resolved_table.startswith("__subquery_"):
                    resolved_table = table_alias

            clause = determine_clause(col_node)
            key = (col_name.lower(), table_alias.lower() if table_alias else None, clause)

            if key not in seen:
                seen.add(key)
                columns.append(
                    ExtractedColumn(
                        name=col_name,
                        table_alias=table_alias,
                        table_name=resolved_table,
                        clause=clause,
                        is_wildcard=False,
                    )
                )

        # 2. Wildcard nodes (e.g. *, c.*)
        for star_node in ast_root.find_all(exp.Star):
            table_alias = star_node.table if hasattr(star_node, "table") and star_node.table else None
            resolved_table = None
            if table_alias:
                resolved_table = alias_map.get(table_alias.lower(), table_alias)

            clause = determine_clause(star_node)
            columns.append(
                ExtractedColumn(
                    name="*",
                    table_alias=table_alias,
                    table_name=resolved_table,
                    clause=clause,
                    is_wildcard=True,
                )
            )

        return columns

    @classmethod
    def _extract_joins(
        cls, ast_root: exp.Expression, alias_map: Dict[str, str]
    ) -> List[ExtractedJoin]:
        """Extracts all JOIN clauses, join types, and join ON column conditions."""
        joins: List[ExtractedJoin] = []

        # Find the primary FROM table as default initial left table
        from_node = ast_root.find(exp.From)
        default_left_table = None
        if from_node:
            first_table = from_node.find(exp.Table)
            if first_table:
                default_left_table = first_table.name

        current_left_table = default_left_table

        for join_node in ast_root.find_all(exp.Join):
            right_table_node = join_node.this
            right_table_name = ""
            right_table_alias = None

            if isinstance(right_table_node, exp.Table):
                right_table_name = right_table_node.name
                right_table_alias = right_table_node.alias
            elif isinstance(right_table_node, exp.Subquery):
                right_table_name = right_table_node.alias or "subquery"
                right_table_alias = right_table_node.alias

            # Join type (e.g., LEFT, RIGHT, INNER, FULL, CROSS)
            join_kind = join_node.kind or "INNER"
            join_side = join_node.side or ""
            join_type_str = f"{join_side} {join_kind}".strip().upper() or "INNER"

            # Parse ON condition
            on_expr = join_node.args.get("on")
            condition_raw = on_expr.sql() if on_expr else None
            left_col = None
            right_col = None
            left_tbl = current_left_table

            if on_expr and isinstance(on_expr, exp.EQ):
                left_arg = on_expr.left
                right_arg = on_expr.right

                if isinstance(left_arg, exp.Column) and isinstance(right_arg, exp.Column):
                    l_tbl_alias = left_arg.table
                    r_tbl_alias = right_arg.table

                    l_resolved = alias_map.get(l_tbl_alias.lower()) if l_tbl_alias else current_left_table
                    r_resolved = alias_map.get(r_tbl_alias.lower()) if r_tbl_alias else right_table_name

                    left_tbl = l_resolved
                    left_col = f"{left_tbl}.{left_arg.name}" if left_tbl else left_arg.name
                    right_col = f"{r_resolved}.{right_arg.name}" if r_resolved else right_arg.name

            joins.append(
                ExtractedJoin(
                    left_table=left_tbl,
                    right_table=right_table_name,
                    join_type=join_type_str,
                    condition_raw=condition_raw,
                    left_column=left_col,
                    right_column=right_col,
                )
            )

            # Update current left table for subsequent joins
            if right_table_name:
                current_left_table = right_table_name

        return joins

    @classmethod
    def _extract_conditions(cls, ast_root: exp.Expression) -> List[ExtractedCondition]:
        """Extracts WHERE and HAVING filter conditions and their referenced columns."""
        conditions: List[ExtractedCondition] = []

        where_node = ast_root.find(exp.Where)
        if where_node:
            cols = [c.name for c in where_node.find_all(exp.Column) if c.name]
            conditions.append(
                ExtractedCondition(
                    clause_type="WHERE",
                    raw_expression=where_node.this.sql(),
                    referenced_columns=cols,
                )
            )

        having_node = ast_root.find(exp.Having)
        if having_node:
            cols = [c.name for c in having_node.find_all(exp.Column) if c.name]
            conditions.append(
                ExtractedCondition(
                    clause_type="HAVING",
                    raw_expression=having_node.this.sql(),
                    referenced_columns=cols,
                )
            )

        return conditions
