"""
Deterministic Mock LLM Provider for Testing and Zero-Config Demonstration.
Simulates realistic LLM Text-to-SQL behaviors including valid queries and common hallucinations.
"""
import re
from typing import Dict, Any, Optional
from .base import BaseLLMProvider, LLMResponse


class MockLLMProvider(BaseLLMProvider):
    """
    Deterministic Text-to-SQL generator for automated testing and local demos.
    Maps natural language prompts to predefined SQL queries or follows explicit scenario hints.
    """

    DEFAULT_TEMPLATES = {
        # Valid queries
        "customers_usa": "SELECT name, email, country FROM customers WHERE country = 'USA'",
        "customers_all": "SELECT id, name, email, country FROM customers",
        "employees_engineering": "SELECT e.first_name, e.last_name, d.dept_name FROM employees e JOIN departments d ON e.department_id = d.id WHERE d.dept_name = 'Engineering'",
        "orders_completed": "SELECT c.name, o.total_amount FROM customers c JOIN orders o ON c.id = o.customer_id WHERE o.status = 'COMPLETED'",
        "expensive_products": "SELECT product_name, unit_price FROM products WHERE unit_price > 100.0 ORDER BY unit_price DESC",

        # Hallucination Scenarios
        "hallucinated_table": "SELECT client_id, billing_address FROM client_invoices WHERE status = 'PAID'",
        "hallucinated_column": "SELECT name, phone_number, home_address FROM customers",
        "hallucinated_join": "SELECT e.first_name, d.dept_name FROM employees e JOIN departments d ON e.dept_code = d.dept_code",
        "hallucinated_students": "SELECT * FROM students WHERE program = 'MCA'",
        "malformed_sql": "SELECT FROM WHERE customers",
    }

    def __init__(self, model_name: str = "mock-text-to-sql-v1", custom_mappings: Optional[Dict[str, str]] = None):
        self.model_name = model_name
        self.custom_mappings = custom_mappings or {}
        self._preset_response: Optional[str] = None

    def set_preset_response(self, sql: Optional[str]):
        """Explicitly override the next generated SQL output for fine-grained testing."""
        self._preset_response = sql

    def generate_sql(
        self,
        prompt: str,
        schema_context: Optional[Dict[str, Any]] = None,
        dialect: str = "mysql",
        scenario: Optional[str] = None,
        **kwargs,
    ) -> LLMResponse:
        # 1. Preset override
        if self._preset_response is not None:
            sql = self._preset_response
            return LLMResponse(
                sql_query=sql,
                prompt=prompt,
                provider="mock",
                model=self.model_name,
                metadata={"scenario": "preset_override", "dialect": dialect},
            )

        # 2. Scenario-based generation
        if scenario and scenario in self.DEFAULT_TEMPLATES:
            sql = self.DEFAULT_TEMPLATES[scenario]
            return LLMResponse(
                sql_query=sql,
                prompt=prompt,
                provider="mock",
                model=self.model_name,
                metadata={"scenario": scenario, "dialect": dialect},
            )

        # 3. Custom mappings check
        prompt_lower = prompt.lower().strip()
        for key, mapped_sql in self.custom_mappings.items():
            if key.lower() in prompt_lower:
                return LLMResponse(
                    sql_query=mapped_sql,
                    prompt=prompt,
                    provider="mock",
                    model=self.model_name,
                    metadata={"scenario": "custom_mapping", "matched_key": key, "dialect": dialect},
                )

        # 4. Keyword heuristics for natural language queries
        if "client" in prompt_lower or "invoice" in prompt_lower:
            sql = self.DEFAULT_TEMPLATES["hallucinated_table"]
            matched = "hallucinated_table"
        elif "phone" in prompt_lower or "address" in prompt_lower:
            sql = self.DEFAULT_TEMPLATES["hallucinated_column"]
            matched = "hallucinated_column"
        elif "malformed" in prompt_lower or "syntax error" in prompt_lower:
            sql = self.DEFAULT_TEMPLATES["malformed_sql"]
            matched = "malformed_sql"
        elif "student" in prompt_lower or "mca" in prompt_lower:
            sql = self.DEFAULT_TEMPLATES["hallucinated_students"]
            matched = "hallucinated_students"
        elif "employee" in prompt_lower or "department" in prompt_lower or "engineering" in prompt_lower:
            sql = self.DEFAULT_TEMPLATES["employees_engineering"]
            matched = "employees_engineering"
        elif "order" in prompt_lower or "completed" in prompt_lower:
            sql = self.DEFAULT_TEMPLATES["orders_completed"]
            matched = "orders_completed"
        elif "product" in prompt_lower or "price" in prompt_lower:
            sql = self.DEFAULT_TEMPLATES["expensive_products"]
            matched = "expensive_products"
        elif "usa" in prompt_lower:
            sql = self.DEFAULT_TEMPLATES["customers_usa"]
            matched = "customers_usa"
        elif "customer" in prompt_lower:
            sql = self.DEFAULT_TEMPLATES["customers_all"]
            matched = "customers_all"
        else:
            # For other unsupported natural language prompts, extract the primary entity
            # so non-existent entities are reflected in SQL and caught by the validator
            words = re.findall(r'[a-zA-Z_]+', prompt_lower)
            stopwords = {"find", "all", "get", "show", "list", "select", "in", "from", "where", "the", "a", "an", "of", "with", "for", "to"}
            meaningful = [w for w in words if w not in stopwords]
            if meaningful:
                entity = meaningful[0]
                sql = f"SELECT * FROM {entity}"
                matched = f"unsupported_entity_{entity}"
            else:
                sql = self.DEFAULT_TEMPLATES["customers_all"]
                matched = "customers_all"

        return LLMResponse(
            sql_query=sql,
            prompt=prompt,
            provider="mock",
            model=self.model_name,
            metadata={"scenario": matched, "dialect": dialect},
        )
