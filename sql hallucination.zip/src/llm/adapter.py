"""
LLM-to-Validator Adapter Module.
Connects natural language requests to the LLM provider and immediately pipes the generated SQL
into the deterministic validation pipeline without executing arbitrary SQL.
"""
import time
from typing import Dict, Any, Optional

from .base import BaseLLMProvider, LLMResponse
from .mock_provider import MockLLMProvider
from src.preprocessor.preprocessor import QueryPreprocessor
from src.parser.ast_parser import ASTParser
from src.extractor.schema_extractor import SchemaExtractor
from src.validator.schema_inspector import SchemaInspector
from src.validator.schema_validator import SchemaValidator
from src.decision.decision_engine import DecisionEngine, ValidationResult
from src.logger.audit_logger import AuditLogger
from config.settings import Config


class LLMAdapter:
    """
    Orchestrates the conversion of natural language requests into SQL via an LLM provider,
    and subjects the generated query to deterministic AST-based schema validation.
    """

    def __init__(self, provider: Optional[BaseLLMProvider] = None):
        if provider:
            self.provider = provider
        elif Config.LLM_PROVIDER == "gemini":
            from .gemini_provider import GeminiLLMProvider
            self.provider = GeminiLLMProvider()
        else:
            self.provider = MockLLMProvider()

    def process_natural_language_query(
        self,
        prompt: str,
        dialect: Optional[str] = None,
        database_config: Optional[Dict[str, Any]] = None,
        scenario: Optional[str] = None,
        client_ip: str = "127.0.0.1",
        execute_if_valid: bool = False,
    ) -> Dict[str, Any]:
        """
        Executes the full LLM-to-Validator workflow:
        1. Introspects live schema context for the LLM.
        2. Generates SQL from the natural language prompt.
        3. Preprocesses, parses to AST, extracts schema footprint, and validates against live database.
        4. Makes deterministic allow/block decision and safely executes valid queries against live database.
        """
        start_time = time.time()
        target_dialect = dialect or "mysql"

        db_config = database_config or {
            "db_type": Config.DEFAULT_DB_TYPE,
            "database_path": Config.DEFAULT_SQLITE_PATH,
            "database": "demo_enterprise.db",
        }

        # 1. Fetch live schema context
        try:
            live_schema = SchemaInspector.fetch_live_schema(db_config, ttl_seconds=Config.SCHEMA_CACHE_TTL)
        except Exception:
            live_schema = {"tables": [], "columns": {}, "relationships": []}

        # 2. Invoke LLM provider to translate natural language to SQL
        try:
            llm_response: LLMResponse = self.provider.generate_sql(
                prompt=prompt,
                schema_context=live_schema,
                dialect=target_dialect,
                scenario=scenario,
            )
        except Exception as e:
            if not isinstance(self.provider, MockLLMProvider):
                fallback = MockLLMProvider()
                llm_response = fallback.generate_sql(
                    prompt=prompt,
                    schema_context=live_schema,
                    dialect=target_dialect,
                    scenario=scenario,
                )
                llm_response.provider = f"mock (fallback: {str(e)[:60]}...)"
                llm_response.metadata["fallback_warning"] = str(e)
            else:
                raise e

        generated_sql = llm_response.sql_query

        # 3. Pipe generated SQL through the existing deterministic validation pipeline
        norm_sql, detected_dialect, prep_err = QueryPreprocessor.process(generated_sql, target_dialect)
        
        if prep_err:
            val_result = DecisionEngine.evaluate(
                sql_query=generated_sql,
                dialect=detected_dialect,
                extracted_elements={},
                hallucinations=[],
                syntax_error=prep_err,
                execute_if_valid=False,
                db_config=db_config,
            )
            duration_ms = (time.time() - start_time) * 1000.0
            AuditLogger.log_validation(generated_sql, detected_dialect, val_result.status, val_result.is_valid, val_result.hallucinations, duration_ms, client_ip)
            return self._build_combined_response(prompt, llm_response, val_result)

        ast_root, syntax_err = ASTParser.parse(norm_sql, detected_dialect)
        if syntax_err:
            val_result = DecisionEngine.evaluate(
                sql_query=norm_sql,
                dialect=detected_dialect,
                extracted_elements={},
                hallucinations=[],
                syntax_error=syntax_err,
                execute_if_valid=False,
                db_config=db_config,
            )
            duration_ms = (time.time() - start_time) * 1000.0
            AuditLogger.log_validation(norm_sql, detected_dialect, val_result.status, val_result.is_valid, val_result.hallucinations, duration_ms, client_ip)
            return self._build_combined_response(prompt, llm_response, val_result)

        extracted = SchemaExtractor.extract(ast_root, detected_dialect)
        hallucinations = SchemaValidator.validate(extracted, live_schema)

        # Safely execute query only if validation passes
        val_result = DecisionEngine.evaluate(
            sql_query=norm_sql,
            dialect=detected_dialect,
            extracted_elements=extracted.to_dict(),
            hallucinations=hallucinations,
            execute_if_valid=execute_if_valid,
            db_config=db_config,
        )

        duration_ms = (time.time() - start_time) * 1000.0
        AuditLogger.log_validation(norm_sql, detected_dialect, val_result.status, val_result.is_valid, val_result.hallucinations, duration_ms, client_ip)

        return self._build_combined_response(prompt, llm_response, val_result)

    def _build_combined_response(
        self, prompt: str, llm_response: LLMResponse, val_result: ValidationResult
    ) -> Dict[str, Any]:
        """Combines LLM generation metadata with deterministic validation results and safe execution."""
        if not val_result.is_valid:
            execution = {
                "executed": False,
                "status": "NOT_EXECUTED",
                "columns": [],
                "rows": [],
                "row_count": 0,
                "error": None,
            }
        elif val_result.execution_error:
            execution = {
                "executed": False,
                "status": "FAILED",
                "columns": [],
                "rows": [],
                "row_count": 0,
                "error": val_result.execution_error,
            }
        elif val_result.execution_data is not None:
            data = val_result.execution_data
            if data and len(data) > 0:
                columns = list(data[0].keys())
                rows = [[row.get(col) for col in columns] for row in data]
            else:
                columns = []
                rows = []
            execution = {
                "executed": True,
                "status": "SUCCESS",
                "columns": columns,
                "rows": rows,
                "row_count": len(rows),
                "error": None,
            }
        else:
            execution = {
                "executed": False,
                "status": "NOT_EXECUTED",
                "columns": [],
                "rows": [],
                "row_count": 0,
                "error": None,
            }

        return {
            "prompt": prompt,
            "generated_sql": llm_response.sql_query,
            "llm_metadata": {
                "provider": llm_response.provider,
                "model": llm_response.model,
                "metadata": llm_response.metadata,
            },
            "validation": val_result.to_dict(),
            "status": val_result.status,
            "is_valid": val_result.is_valid,
            "hallucinations": val_result.hallucinations,
            "message": val_result.message,
            "execution": execution,
        }

