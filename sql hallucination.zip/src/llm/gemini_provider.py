"""
Google Gemini LLM Provider.
Generates SQL from natural language questions using the Gemini API.
"""
import os
import re
from typing import Dict, Any, Optional

from .base import BaseLLMProvider, LLMResponse
from config.settings import Config

try:
    from google import genai
    from google.genai import types
except ImportError:
    genai = None


class GeminiLLMProvider(BaseLLMProvider):
    """
    LLM provider that integrates with Google Gemini API.
    """

    def __init__(self):
        if genai is None:
            raise ImportError("The 'google-genai' library is not installed. Please install it.")
        
        self.api_key = Config.GEMINI_API_KEY
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY environment variable is missing.")
            
        self.model_name = Config.GEMINI_MODEL
        self.client = genai.Client(
            api_key=self.api_key
        )

    def generate_sql(
        self,
        prompt: str,
        schema_context: Optional[Dict[str, Any]] = None,
        dialect: str = "mysql",
        **kwargs,
    ) -> LLMResponse:
        """
        Translates a natural language user prompt into an SQL query using Gemini.
        """
        # Construct schema representation for the prompt
        schema_info = "Database Schema:\n"
        if schema_context and "tables" in schema_context:
            for table in schema_context["tables"]:
                schema_info += f"Table: {table}\n"
                cols = schema_context.get("columns", {}).get(table, [])
                if cols:
                    schema_info += f"  Columns: {', '.join(cols)}\n"
        else:
            schema_info += "No schema provided.\n"

        system_instruction = (
            "You are an expert SQL generation assistant. "
            "Translate the natural language request directly into a single SQL query matching the user intent. "
            f"The target database dialect is {dialect.upper()}.\n"
            f"{schema_info}\n"
            "Translate the tables and columns as requested by the user. If the user asks for specific entities or fields (e.g., invoices, phone numbers, students), reflect those requested table/column names in the SQL query rather than substituting unrelated tables. "
            "Return ONLY the SQL query. "
            "Do NOT include explanations. "
            "Do NOT return Markdown code blocks (e.g. ```sql). "
            "Do NOT execute SQL, validate SQL, or claim that SQL is valid. "
            "Return exactly one SQL statement."
        )

        # Build model candidate list: user model first, then resilient fallbacks
        candidate_models = []
        if self.model_name:
            candidate_models.append(self.model_name)
        for fallback in ["gemini-flash-lite-latest", "gemini-3-flash-preview", "gemini-flash-latest"]:
            if fallback not in candidate_models:
                candidate_models.append(fallback)

        last_error = None
        for model_to_try in candidate_models:
            try:
                response = self.client.models.generate_content(
                    model=model_to_try,
                    contents=prompt,
                    config=types.GenerateContentConfig(
                        system_instruction=system_instruction,
                        temperature=0.0,
                    ),
                )
                
                raw_response = response.text if response.text else ""
                
                # Clean up the output in case the model returns markdown code blocks
                sql_query = self._extract_sql(raw_response)
                
                if not sql_query:
                    raise ValueError("Unable to extract valid SQL from the LLM response.")

                return LLMResponse(
                    sql_query=sql_query.strip(),
                    prompt=prompt,
                    provider="gemini",
                    model=model_to_try,
                    metadata={"raw_response": raw_response, "used_model": model_to_try}
                )
            except ValueError as ve:
                raise ve
            except Exception as e:
                err_str = str(e)
                last_error = e
                # Check for 404 (model retired), 503 (demand spike), or 429 (rate limit) to try fallback model
                if ("404" in err_str or "503" in err_str or "429" in err_str or "NOT_FOUND" in err_str or "UNAVAILABLE" in err_str) and model_to_try != candidate_models[-1]:
                    continue
                break

        # If all candidates failed, raise descriptive RuntimeError
        raise RuntimeError(f"LLM generation failed: {str(last_error)}")

    def _extract_sql(self, text: str) -> str:
        """Safely extracts SQL from the response, handling markdown blocks."""
        text = text.strip()
        if not text:
            return ""
        # Remove ```sql ... ``` or ``` ... ```
        match = re.search(r"```(?:sql)?\s*(.*?)\s*```", text, re.IGNORECASE | re.DOTALL)
        if match:
            return match.group(1).strip()
        return text
