"""
Abstract Base Classes and Data Models for LLM Providers.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Any, Optional


@dataclass
class LLMResponse:
    """Standardized response from an LLM Text-to-SQL provider."""
    sql_query: str
    prompt: str
    provider: str
    model: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sql_query": self.sql_query,
            "prompt": self.prompt,
            "provider": self.provider,
            "model": self.model,
            "metadata": self.metadata,
        }


class BaseLLMProvider(ABC):
    """Abstract interface for all LLM Text-to-SQL providers."""

    @abstractmethod
    def generate_sql(
        self,
        prompt: str,
        schema_context: Optional[Dict[str, Any]] = None,
        dialect: str = "mysql",
        **kwargs,
    ) -> LLMResponse:
        """
        Translates a natural language user prompt into an SQL query.
        
        Args:
            prompt: The user's natural language question.
            schema_context: Metadata describing available database tables and columns.
            dialect: The target SQL dialect (e.g., 'mysql', 'postgres', 'sqlite').
            **kwargs: Provider-specific options.

        Returns:
            LLMResponse object containing generated SQL and execution metadata.
        """
        pass
