"""
AST Parsing Module (Section 5.3.3)
Parses preprocessed SQL into an Abstract Syntax Tree (AST) using sqlglot.
Handles tokenization, tree generation, alias scope resolution, and syntax error detection.
"""
from typing import Tuple, Optional, Dict, Set
import sqlglot
from sqlglot import exp
from sqlglot.errors import ParseError


class ASTParser:
    """Provides AST parsing, syntax validation, and AST inspection utilities."""

    @staticmethod
    def parse(sql: str, dialect: str = "mysql") -> Tuple[Optional[exp.Expression], Optional[str]]:
        """
        Parses normalized SQL query string into a sqlglot AST Expression.
        Returns:
            (ast_root, error_message)
        """
        if not sql or not sql.strip():
            return None, "Cannot parse empty SQL query."

        # Map dialect for sqlglot
        read_dialect = "postgres" if dialect in ("postgres", "postgresql") else dialect

        try:
            # parse_one parses a single SQL statement into an AST root
            ast_root = sqlglot.parse_one(sql, read=read_dialect)
            if ast_root is None:
                return None, "Failed to generate AST: parser returned None."
            return ast_root, None
        except ParseError as e:
            # Extract clean error details
            error_details = str(e)
            return None, f"SQL Syntax / Parsing Error: {error_details}"
        except Exception as e:
            return None, f"Unexpected AST parsing error: {str(e)}"

    @staticmethod
    def get_cte_names(ast_root: exp.Expression) -> Set[str]:
        """
        Extracts the names of Common Table Expressions (WITH clauses) in the query.
        """
        cte_names = set()
        for cte in ast_root.find_all(exp.CTE):
            alias_name = cte.alias_or_name
            if alias_name:
                cte_names.add(alias_name.lower())
        return cte_names

    @staticmethod
    def get_table_alias_map(ast_root: exp.Expression) -> Dict[str, str]:
        """
        Builds a dictionary mapping table aliases to physical table names.
        e.g., {'c': 'customers', 'o': 'orders'}
        """
        alias_map: Dict[str, str] = {}
        for table in ast_root.find_all(exp.Table):
            table_name = table.name.lower() if table.name else ""
            table_alias = table.alias.lower() if table.alias else ""
            if table_alias and table_name:
                alias_map[table_alias] = table_name
            elif table_name:
                # Table maps to itself as default alias
                alias_map[table_name] = table_name

        # Also handle subqueries with aliases: (SELECT ...) AS sub
        for subquery in ast_root.find_all(exp.Subquery):
            if subquery.alias:
                alias_map[subquery.alias.lower()] = f"__subquery_{subquery.alias.lower()}__"

        return alias_map
