"""SQL Hallucination Validator source package."""
