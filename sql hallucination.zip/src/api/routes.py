"""
Flask REST API Blueprint (Section 5.3.1)
Exposes endpoints for SQL validation, execution, audit log retrieval, and health checks.
"""
import time
from flask import Blueprint, request, jsonify
from pydantic import ValidationError

from .schemas import ValidationRequestSchema, NaturalLanguageQueryRequestSchema
from src.preprocessor.preprocessor import QueryPreprocessor
from src.parser.ast_parser import ASTParser
from src.extractor.schema_extractor import SchemaExtractor
from src.validator.schema_inspector import SchemaInspector
from src.validator.schema_validator import SchemaValidator
from src.decision.decision_engine import DecisionEngine
from src.logger.audit_logger import AuditLogger
from src.llm.adapter import LLMAdapter
from config.settings import Config

api_bp = Blueprint("api", __name__, url_prefix="/api/v1")


def get_default_db_config() -> dict:
    return {
        "db_type": Config.DEFAULT_DB_TYPE,
        "database_path": Config.DEFAULT_SQLITE_PATH,
        "database": "demo_enterprise.db"
    }


def execute_validation_pipeline(req_data: dict, execute: bool = False):
    start_time = time.time()
    client_ip = request.remote_addr or "127.0.0.1"

    # 1. Pydantic Request Validation
    try:
        validated_req = ValidationRequestSchema(**req_data)
    except ValidationError as err:
        return {
            "status": "BLOCKED",
            "is_valid": False,
            "dialect": "unknown",
            "extracted_elements": {},
            "hallucinations": [{
                "type": "REQUEST_VALIDATION_ERROR",
                "element": None,
                "table": None,
                "error_message": str(err),
                "suggestion": "Ensure valid JSON payload with 'sql_query' field."
            }],
            "message": "Malformed request payload.",
        }, 400

    raw_sql = validated_req.sql_query
    dialect_hint = validated_req.dialect
    db_config = validated_req.database_config.model_dump() if validated_req.database_config else get_default_db_config()

    # 2. Module 2: Preprocessing
    norm_sql, dialect, prep_err = QueryPreprocessor.process(raw_sql, dialect_hint)
    if prep_err:
        res = DecisionEngine.evaluate(
            sql_query=raw_sql,
            dialect=dialect,
            extracted_elements={},
            hallucinations=[],
            syntax_error=prep_err,
            execute_if_valid=False,
            db_config=db_config,
        )
        duration_ms = (time.time() - start_time) * 1000.0
        AuditLogger.log_validation(raw_sql, dialect, res.status, res.is_valid, res.hallucinations, duration_ms, client_ip)
        return res.to_dict(), 200

    # 3. Module 3: AST Parsing
    ast_root, syntax_err = ASTParser.parse(norm_sql, dialect)
    if syntax_err:
        res = DecisionEngine.evaluate(
            sql_query=norm_sql,
            dialect=dialect,
            extracted_elements={},
            hallucinations=[],
            syntax_error=syntax_err,
            execute_if_valid=False,
            db_config=db_config,
        )
        duration_ms = (time.time() - start_time) * 1000.0
        AuditLogger.log_validation(norm_sql, dialect, res.status, res.is_valid, res.hallucinations, duration_ms, client_ip)
        return res.to_dict(), 200

    # 4. Module 4: Schema Extraction
    extracted = SchemaExtractor.extract(ast_root, dialect)

    # 5. Module 5: Live Schema Validation
    try:
        live_schema = SchemaInspector.fetch_live_schema(db_config, ttl_seconds=Config.SCHEMA_CACHE_TTL)
    except Exception as e:
        res = DecisionEngine.evaluate(
            sql_query=norm_sql,
            dialect=dialect,
            extracted_elements=extracted.to_dict(),
            hallucinations=[{
                "type": "DATABASE_CONNECTION_ERROR",
                "element": None,
                "table": None,
                "error_message": f"Failed to connect to target database: {str(e)}",
                "suggestion": "Verify database credentials, host, port, and schema name."
            }],
            execute_if_valid=False,
            db_config=db_config,
        )
        duration_ms = (time.time() - start_time) * 1000.0
        AuditLogger.log_validation(norm_sql, dialect, res.status, res.is_valid, res.hallucinations, duration_ms, client_ip)
        return res.to_dict(), 200

    hallucinations = SchemaValidator.validate(extracted, live_schema)

    # 6. Module 6: Decision Engine
    res = DecisionEngine.evaluate(
        sql_query=norm_sql,
        dialect=dialect,
        extracted_elements=extracted.to_dict(),
        hallucinations=hallucinations,
        execute_if_valid=execute or validated_req.execute_if_valid,
        db_config=db_config,
    )

    # 7. Module 7: Audit Logging
    duration_ms = (time.time() - start_time) * 1000.0
    AuditLogger.log_validation(norm_sql, dialect, res.status, res.is_valid, res.hallucinations, duration_ms, client_ip)

    return res.to_dict(), 200


@api_bp.route("/validate", methods=["POST"])
def validate_query():
    """Validates an AI-generated SQL query against live schema without execution."""
    data = request.get_json() or {}
    result, status_code = execute_validation_pipeline(data, execute=False)
    return jsonify(result), status_code


@api_bp.route("/validate-and-execute", methods=["POST"])
def validate_and_execute_query():
    """Validates an AI-generated SQL query and executes it safely if valid."""
    data = request.get_json() or {}
    result, status_code = execute_validation_pipeline(data, execute=True)
    return jsonify(result), status_code


@api_bp.route("/generate-and-validate", methods=["POST"])
def generate_and_validate_query():
    """
    Translates a natural language database question into SQL via LLM adapter,
    subjects the generated SQL to deterministic AST schema validation,
    and safely executes against the database if validation passes.
    """
    data = request.get_json() or {}
    try:
        req = NaturalLanguageQueryRequestSchema(**data)
    except ValidationError as err:
        return jsonify({
            "status": "BLOCKED",
            "is_valid": False,
            "prompt": data.get("prompt", ""),
            "generated_sql": "",
            "llm_metadata": {},
            "hallucinations": [{
                "type": "REQUEST_VALIDATION_ERROR",
                "element": None,
                "table": None,
                "error_message": str(err),
                "suggestion": "Ensure valid JSON payload with non-empty 'prompt' field."
            }],
            "message": "Malformed request payload.",
            "extracted_elements": {},
            "validation": {},
            "execution": {
                "executed": False,
                "status": "NOT_EXECUTED",
                "columns": [],
                "rows": [],
                "row_count": 0,
                "error": None,
            },
        }), 400

    client_ip = request.remote_addr or "127.0.0.1"
    db_config = req.database_config.model_dump() if req.database_config else get_default_db_config()

    adapter = LLMAdapter()
    try:
        result = adapter.process_natural_language_query(
            prompt=req.prompt,
            dialect=req.dialect,
            database_config=db_config,
            scenario=req.scenario,
            client_ip=client_ip,
            execute_if_valid=req.execute_if_valid if req.execute_if_valid is not None else True,
        )
        result["extracted_elements"] = result.get("validation", {}).get("extracted_elements", {})
        return jsonify(result), 200
    except Exception as e:
        return jsonify({
            "status": "ERROR",
            "is_valid": False,
            "prompt": req.prompt,
            "generated_sql": "",
            "llm_metadata": {},
            "hallucinations": [{
                "type": "LLM_GENERATION_ERROR",
                "element": None,
                "table": None,
                "error_message": str(e),
                "suggestion": "Check LLM configuration and API key."
            }],
            "message": str(e),
            "extracted_elements": {},
            "validation": {},
            "execution": {
                "executed": False,
                "status": "NOT_EXECUTED",
                "columns": [],
                "rows": [],
                "row_count": 0,
                "error": None,
            },
        }), 500



@api_bp.route("/logs", methods=["GET"])
def get_logs():
    """Retrieves validation audit logs."""
    limit = int(request.args.get("limit", 50))
    status = request.args.get("status")
    offset = int(request.args.get("offset", 0))
    logs = AuditLogger.get_logs(limit=limit, status=status, offset=offset)
    return jsonify({"logs": logs, "count": len(logs)})


@api_bp.route("/health", methods=["GET"])
def health():
    """Health check endpoint."""
    return jsonify({
        "status": "healthy",
        "service": "SQL Hallucination Validator for AI Assistants",
        "version": "1.0.0"
    })
