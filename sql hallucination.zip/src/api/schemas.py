"""
Pydantic Schemas for API Request and Response Serialization.
"""
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field


class DatabaseConfigSchema(BaseModel):
    db_type: str = Field("sqlite", description="Database engine: 'mysql', 'postgres', or 'sqlite'")
    host: Optional[str] = Field("localhost", description="Database host")
    port: Optional[int] = Field(None, description="Port number")
    user: Optional[str] = Field(None, description="Username")
    password: Optional[str] = Field("", description="Password")
    database: Optional[str] = Field(None, description="Database or schema name")
    database_path: Optional[str] = Field(None, description="File path for SQLite database")
    schema_name: Optional[str] = Field("public", description="Schema name for PostgreSQL")


class ValidationRequestSchema(BaseModel):
    sql_query: str = Field(..., description="The AI-generated SQL query to validate")
    dialect: Optional[str] = Field(None, description="SQL dialect hint: 'mysql', 'postgres', or 'sqlite'")
    database_config: Optional[DatabaseConfigSchema] = Field(None, description="Target database connection details")
    execute_if_valid: Optional[bool] = Field(False, description="Whether to execute the query if validation passes")


class HallucinationItemSchema(BaseModel):
    type: str
    element: Optional[str] = None
    table: Optional[str] = None
    clause: Optional[str] = None
    error_message: str
    suggestion: Optional[str] = None


class ValidationResponseSchema(BaseModel):
    status: str
    is_valid: bool
    dialect: str
    extracted_elements: Dict[str, Any]
    hallucinations: List[HallucinationItemSchema]
    message: str
    timestamp: str
    execution_data: Optional[List[Dict[str, Any]]] = None
    row_count: Optional[int] = None
    execution_error: Optional[str] = None


class ExecutionResultSchema(BaseModel):
    executed: bool = Field(False, description="Whether SQL execution was performed")
    status: str = Field("NOT_EXECUTED", description="Execution status: 'SUCCESS', 'FAILED', or 'NOT_EXECUTED'")
    columns: List[str] = Field(default_factory=list, description="Column names returned from database")
    rows: List[List[Any]] = Field(default_factory=list, description="Row values returned from database")
    row_count: int = Field(0, description="Total number of rows returned")
    error: Optional[str] = Field(None, description="Execution error message if failed")


class NaturalLanguageQueryRequestSchema(BaseModel):
    prompt: str = Field(..., min_length=1, description="The natural language question to translate to SQL")
    dialect: Optional[str] = Field("mysql", description="Target SQL dialect: 'mysql', 'postgres', or 'sqlite'")
    database_config: Optional[DatabaseConfigSchema] = Field(None, description="Target database connection details")
    scenario: Optional[str] = Field(None, description="Optional deterministic mock scenario identifier")
    execute_if_valid: Optional[bool] = Field(True, description="Whether to safely execute valid queries against the database")


class NaturalLanguageQueryResponseSchema(BaseModel):
    prompt: str
    generated_sql: str
    llm_metadata: Dict[str, Any]
    status: str
    is_valid: bool
    message: str
    hallucinations: List[HallucinationItemSchema]
    extracted_elements: Dict[str, Any]
    validation: Dict[str, Any]
    execution: Optional[ExecutionResultSchema] = None

