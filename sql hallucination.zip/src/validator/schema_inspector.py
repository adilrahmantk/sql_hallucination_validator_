"""
Live Database Schema Inspector (Section 5.3.5)
Extracts table names, column names, data types, and foreign key relationships
from live database information_schema or system catalogs, with in-memory caching.
"""
import time
from typing import Dict, Any, List, Optional, Tuple
from .db_connector import DatabaseConnector


class SchemaInspector:
    """Introspects live database metadata and caches schema snapshots."""

    _cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}

    @classmethod
    def _make_cache_key(cls, db_config: Dict[str, Any]) -> str:
        db_type = db_config.get("db_type", "sqlite").lower()
        if db_type == "sqlite":
            return f"sqlite:{db_config.get('database_path') or db_config.get('database', 'default')}"
        host = db_config.get("host", "localhost")
        port = db_config.get("port", 0)
        db = db_config.get("database", "")
        return f"{db_type}:{host}:{port}:{db}"

    @classmethod
    def fetch_live_schema(cls, db_config: Dict[str, Any], ttl_seconds: int = 300, force_refresh: bool = False) -> Dict[str, Any]:
        """
        Fetches tables, columns, and relationships from the database.
        Uses in-memory cache if available and unexpired.
        """
        cache_key = cls._make_cache_key(db_config)
        now = time.time()

        if not force_refresh and cache_key in cls._cache:
            timestamp, cached_schema = cls._cache[cache_key]
            if now - timestamp < ttl_seconds:
                return cached_schema

        db_type = db_config.get("db_type", "sqlite").lower()
        if db_type == "sqlite":
            schema_data = cls._inspect_sqlite(db_config)
        elif db_type == "mysql":
            schema_data = cls._inspect_mysql(db_config)
        elif db_type in ("postgres", "postgresql"):
            schema_data = cls._inspect_postgres(db_config)
        else:
            raise ValueError(f"Unsupported database type: {db_type}")

        cls._cache[cache_key] = (now, schema_data)
        return schema_data

    @classmethod
    def _inspect_sqlite(cls, db_config: Dict[str, Any]) -> Dict[str, Any]:
        """Inspects SQLite database schema using sqlite_master and PRAGMA commands."""
        conn = DatabaseConnector.get_connection(db_config)
        cursor = conn.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")
        tables = [row[0] for row in cursor.fetchall()]

        columns: Dict[str, Dict[str, Any]] = {}
        relationships: List[Dict[str, Any]] = []

        for tbl in tables:
            columns[tbl.lower()] = {}
            cursor.execute(f"PRAGMA table_info('{tbl}');")
            for col_row in cursor.fetchall():
                c_name = col_row[1]
                c_type = col_row[2]
                columns[tbl.lower()][c_name.lower()] = {
                    "original_name": c_name,
                    "type": c_type,
                    "is_pk": bool(col_row[5]),
                }

            cursor.execute(f"PRAGMA foreign_key_list('{tbl}');")
            for fk_row in cursor.fetchall():
                relationships.append({
                    "table": tbl.lower(),
                    "column": fk_row[3].lower() if fk_row[3] else "",
                    "ref_table": fk_row[2].lower() if fk_row[2] else "",
                    "ref_column": fk_row[4].lower() if fk_row[4] else "",
                })

        cursor.close()
        conn.close()

        return {
            "tables": [t.lower() for t in tables],
            "tables_original": tables,
            "columns": columns,
            "relationships": relationships,
        }

    @classmethod
    def _inspect_mysql(cls, db_config: Dict[str, Any]) -> Dict[str, Any]:
        """Inspects MySQL database schema using information_schema."""
        db_name = db_config.get("database", "")
        conn = DatabaseConnector.get_connection(db_config)
        cursor = conn.cursor()

        cursor.execute(
            "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s;",
            (db_name,),
        )
        tables = [row[0] if isinstance(row, (list, tuple)) else row["TABLE_NAME"] for row in cursor.fetchall()]

        cursor.execute(
            """
            SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, COLUMN_KEY 
            FROM information_schema.COLUMNS 
            WHERE TABLE_SCHEMA = %s;
            """,
            (db_name,),
        )
        columns: Dict[str, Dict[str, Any]] = {t.lower(): {} for t in tables}
        for row in cursor.fetchall():
            t_name = row[0] if isinstance(row, (list, tuple)) else row["TABLE_NAME"]
            c_name = row[1] if isinstance(row, (list, tuple)) else row["COLUMN_NAME"]
            c_type = row[2] if isinstance(row, (list, tuple)) else row["DATA_TYPE"]
            c_key = row[3] if isinstance(row, (list, tuple)) else row["COLUMN_KEY"]
            if t_name.lower() in columns:
                columns[t_name.lower()][c_name.lower()] = {
                    "original_name": c_name,
                    "type": c_type,
                    "is_pk": (c_key == "PRI"),
                }

        cursor.execute(
            """
            SELECT TABLE_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME
            FROM information_schema.KEY_COLUMN_USAGE
            WHERE TABLE_SCHEMA = %s AND REFERENCED_TABLE_NAME IS NOT NULL;
            """,
            (db_name,),
        )
        relationships = []
        for row in cursor.fetchall():
            t_name = row[0] if isinstance(row, (list, tuple)) else row["TABLE_NAME"]
            c_name = row[1] if isinstance(row, (list, tuple)) else row["COLUMN_NAME"]
            ref_t = row[2] if isinstance(row, (list, tuple)) else row["REFERENCED_TABLE_NAME"]
            ref_c = row[3] if isinstance(row, (list, tuple)) else row["REFERENCED_COLUMN_NAME"]
            relationships.append({
                "table": t_name.lower(),
                "column": c_name.lower(),
                "ref_table": ref_t.lower(),
                "ref_column": ref_c.lower(),
            })

        cursor.close()
        conn.close()

        return {
            "tables": [t.lower() for t in tables],
            "tables_original": tables,
            "columns": columns,
            "relationships": relationships,
        }

    @classmethod
    def _inspect_postgres(cls, db_config: Dict[str, Any]) -> Dict[str, Any]:
        """Inspects PostgreSQL database schema using information_schema."""
        schema_name = db_config.get("schema", "public")
        conn = DatabaseConnector.get_connection(db_config)
        cursor = conn.cursor()

        cursor.execute(
            "SELECT table_name FROM information_schema.tables WHERE table_schema = %s;",
            (schema_name,),
        )
        tables = [row["table_name"] if isinstance(row, dict) else row[0] for row in cursor.fetchall()]

        cursor.execute(
            """
            SELECT table_name, column_name, data_type 
            FROM information_schema.columns 
            WHERE table_schema = %s;
            """,
            (schema_name,),
        )
        columns: Dict[str, Dict[str, Any]] = {t.lower(): {} for t in tables}
        for row in cursor.fetchall():
            t_name = row["table_name"] if isinstance(row, dict) else row[0]
            c_name = row["column_name"] if isinstance(row, dict) else row[1]
            c_type = row["data_type"] if isinstance(row, dict) else row[2]
            if t_name.lower() in columns:
                columns[t_name.lower()][c_name.lower()] = {
                    "original_name": c_name,
                    "type": c_type,
                    "is_pk": False,
                }

        cursor.execute(
            """
            SELECT
                tc.table_name, 
                kcu.column_name, 
                ccu.table_name AS referenced_table_name,
                ccu.column_name AS referenced_column_name 
            FROM information_schema.table_constraints AS tc 
            JOIN information_schema.key_column_usage AS kcu
              ON tc.constraint_name = kcu.constraint_name
              AND tc.table_schema = kcu.table_schema
            JOIN information_schema.constraint_column_usage AS ccu
              ON ccu.constraint_name = tc.constraint_name
              AND ccu.table_schema = tc.table_schema
            WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_schema = %s;
            """,
            (schema_name,),
        )
        relationships = []
        for row in cursor.fetchall():
            t_name = row["table_name"] if isinstance(row, dict) else row[0]
            c_name = row["column_name"] if isinstance(row, dict) else row[1]
            ref_t = row["referenced_table_name"] if isinstance(row, dict) else row[2]
            ref_c = row["referenced_column_name"] if isinstance(row, dict) else row[3]
            relationships.append({
                "table": t_name.lower(),
                "column": c_name.lower(),
                "ref_table": ref_t.lower(),
                "ref_column": ref_c.lower(),
            })

        cursor.close()
        conn.close()

        return {
            "tables": [t.lower() for t in tables],
            "tables_original": tables,
            "columns": columns,
            "relationships": relationships,
        }
