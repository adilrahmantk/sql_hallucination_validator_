"""
Live Schema Validation Module (Section 5.3.5)
Performs deterministic cross-verification between extracted AST schema elements
and live database schema metadata (information_schema).
"""
import difflib
from typing import List, Dict, Any, Optional
from ..extractor.models import ExtractedElements


class SchemaValidator:
    """Validates extracted AST elements against live database schema."""

    @classmethod
    def validate(cls, elements: ExtractedElements, live_schema: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Cross-checks tables, columns, and joins against live_schema.
        Returns a list of detected hallucination items (empty if completely valid).
        """
        hallucinations: List[Dict[str, Any]] = []

        live_tables = set(live_schema.get("tables", []))
        live_columns = live_schema.get("columns", {})  # {table_name: {col_name: info}}
        live_relationships = live_schema.get("relationships", [])

        # Set of CTEs and subquery virtual tables in the query
        virtual_tables = set(c.lower() for c in elements.ctes)
        for t in elements.tables:
            if t.is_subquery or t.is_cte:
                virtual_tables.add(t.name.lower())

        # 1. Validate Tables
        physical_tables_in_query = []
        for table in elements.tables:
            tbl_name_low = table.name.lower()
            if tbl_name_low in virtual_tables:
                continue

            if tbl_name_low not in live_tables:
                suggestions = difflib.get_close_matches(tbl_name_low, list(live_tables), n=3, cutoff=0.5)
                hallucinations.append({
                    "type": "NON_EXISTENT_TABLE",
                    "element": table.name,
                    "table": table.name,
                    "error_message": f"Table '{table.name}' does not exist in the database schema.",
                    "suggestion": f"Available tables: {sorted(list(live_tables))}" if not suggestions else f"Did you mean: {suggestions}?",
                })
            else:
                physical_tables_in_query.append(tbl_name_low)

        # 2. Validate Columns
        for col in elements.columns:
            if col.is_wildcard:
                if col.table_name:
                    tbl_low = col.table_name.lower()
                    if tbl_low not in virtual_tables and tbl_low not in live_tables:
                        hallucinations.append({
                            "type": "NON_EXISTENT_TABLE",
                            "element": col.table_name,
                            "table": col.table_name,
                            "error_message": f"Table '{col.table_name}' referenced in wildcard '{col.table_alias}.*' does not exist.",
                            "suggestion": f"Available tables: {sorted(list(live_tables))}",
                        })
                continue

            col_name_low = col.name.lower()

            # Qualified column: table.column (e.g., c.email -> customers.email)
            if col.table_name:
                tbl_name_low = col.table_name.lower()
                if tbl_name_low in virtual_tables:
                    continue

                if tbl_name_low in live_tables:
                    valid_cols_for_table = live_columns.get(tbl_name_low, {})
                    if col_name_low not in valid_cols_for_table:
                        available = list(valid_cols_for_table.keys())
                        suggestions = difflib.get_close_matches(col_name_low, available, n=3, cutoff=0.5)
                        hallucinations.append({
                            "type": "NON_EXISTENT_COLUMN",
                            "element": col.name,
                            "table": col.table_name,
                            "clause": col.clause,
                            "error_message": f"Column '{col.name}' does not exist in table '{col.table_name}'.",
                            "suggestion": f"Did you mean: {suggestions}?" if suggestions else f"Available columns in '{col.table_name}': {sorted(available)}",
                        })
            else:
                # Unqualified column: search across all physical tables queried
                candidate_tables = [t for t in physical_tables_in_query if t in live_columns]
                matching_tables = [t for t in candidate_tables if col_name_low in live_columns[t]]

                if not matching_tables and candidate_tables:
                    all_queried_cols = []
                    for t in candidate_tables:
                        all_queried_cols.extend([f"{t}.{c}" for c in live_columns[t].keys()])
                    suggestions = difflib.get_close_matches(col_name_low, [c.split(".")[1] for c in all_queried_cols], n=3, cutoff=0.5)
                    
                    hallucinations.append({
                        "type": "NON_EXISTENT_COLUMN",
                        "element": col.name,
                        "table": None,
                        "clause": col.clause,
                        "error_message": f"Unqualified column '{col.name}' does not exist in any of the queried tables: {candidate_tables}.",
                        "suggestion": f"Did you mean: {suggestions}?" if suggestions else f"Available columns: {sorted(all_queried_cols)}",
                    })
                elif len(matching_tables) > 1:
                    hallucinations.append({
                        "type": "AMBIGUOUS_COLUMN",
                        "element": col.name,
                        "table": None,
                        "clause": col.clause,
                        "error_message": f"Column '{col.name}' is ambiguous; it exists in multiple queried tables: {matching_tables}.",
                        "suggestion": f"Please qualify the column as {matching_tables[0]}.{col.name}",
                    })

        # 3. Validate JOIN Relationships
        for join in elements.joins:
            if join.left_column and "." in join.left_column:
                lt, lc = join.left_column.split(".", 1)
                if lt.lower() in live_tables and lc.lower() not in live_columns.get(lt.lower(), {}):
                    hallucinations.append({
                        "type": "INVALID_JOIN_RELATIONSHIP",
                        "element": join.left_column,
                        "table": lt,
                        "error_message": f"Join key column '{lc}' does not exist in table '{lt}'.",
                        "suggestion": f"Valid columns in '{lt}': {sorted(list(live_columns.get(lt.lower(), {}).keys()))}",
                    })

            if join.right_column and "." in join.right_column:
                rt, rc = join.right_column.split(".", 1)
                if rt.lower() in live_tables and rc.lower() not in live_columns.get(rt.lower(), {}):
                    hallucinations.append({
                        "type": "INVALID_JOIN_RELATIONSHIP",
                        "element": join.right_column,
                        "table": rt,
                        "error_message": f"Join key column '{rc}' does not exist in table '{rt}'.",
                        "suggestion": f"Valid columns in '{rt}': {sorted(list(live_columns.get(rt.lower(), {}).keys()))}",
                    })

        return hallucinations
