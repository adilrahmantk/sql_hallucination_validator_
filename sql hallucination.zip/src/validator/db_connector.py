"""
Database Connector Utility.
Manages connections to MySQL, PostgreSQL, and SQLite.
"""
import sqlite3
from typing import Dict, Any, Tuple, Optional, List


class DatabaseConnector:
    """Provides unified database connection and query execution interface."""

    @staticmethod
    def get_connection(db_config: Dict[str, Any]):
        """
        Creates and returns a live database connection object based on db_type.
        """
        db_type = db_config.get("db_type", "sqlite").lower()

        if db_type == "sqlite":
            db_path = db_config.get("database_path") or db_config.get("database", "demo_enterprise.db")
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            return conn

        elif db_type == "mysql":
            try:
                import mysql.connector
                return mysql.connector.connect(
                    host=db_config.get("host", "localhost"),
                    port=int(db_config.get("port", 3306)),
                    user=db_config.get("user", "root"),
                    password=db_config.get("password", ""),
                    database=db_config.get("database", ""),
                    connect_timeout=db_config.get("connect_timeout", 5),
                )
            except ImportError:
                import pymysql
                return pymysql.connect(
                    host=db_config.get("host", "localhost"),
                    port=int(db_config.get("port", 3306)),
                    user=db_config.get("user", "root"),
                    password=db_config.get("password", ""),
                    database=db_config.get("database", ""),
                    connect_timeout=db_config.get("connect_timeout", 5),
                    cursorclass=pymysql.cursors.DictCursor,
                )

        elif db_type in ("postgres", "postgresql"):
            import psycopg2
            from psycopg2.extras import RealDictCursor
            return psycopg2.connect(
                host=db_config.get("host", "localhost"),
                port=int(db_config.get("port", 5432)),
                user=db_config.get("user", "postgres"),
                password=db_config.get("password", ""),
                database=db_config.get("database", "postgres"),
                connect_timeout=db_config.get("connect_timeout", 5),
                cursor_factory=RealDictCursor,
            )

        raise ValueError(f"Unsupported database type: '{db_type}'. Must be 'mysql', 'postgres', or 'sqlite'.")

    @classmethod
    def test_connection(cls, db_config: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """Tests whether a database connection can be established."""
        try:
            conn = cls.get_connection(db_config)
            conn.close()
            return True, None
        except Exception as e:
            return False, str(e)

    @classmethod
    def execute_query(cls, db_config: Dict[str, Any], sql: str) -> Tuple[Optional[List[Dict[str, Any]]], Optional[str]]:
        """
        Safely executes a read query against the database and returns fetched rows as dictionaries.
        """
        try:
            conn = cls.get_connection(db_config)
            cursor = conn.cursor()
            cursor.execute(sql)

            db_type = db_config.get("db_type", "sqlite").lower()

            if db_type == "sqlite":
                rows = cursor.fetchall()
                data = [dict(row) for row in rows]
            elif db_type == "mysql":
                if hasattr(cursor, "fetchall"):
                    rows = cursor.fetchall()
                    if rows and isinstance(rows[0], dict):
                        data = rows
                    elif cursor.description:
                        columns = [col[0] for col in cursor.description]
                        data = [dict(zip(columns, row)) for row in rows]
                    else:
                        data = []
                else:
                    data = []
            elif db_type in ("postgres", "postgresql"):
                rows = cursor.fetchall()
                data = [dict(row) for row in rows]
            else:
                data = []

            cursor.close()
            conn.close()
            return data, None
        except Exception as e:
            return None, str(e)
