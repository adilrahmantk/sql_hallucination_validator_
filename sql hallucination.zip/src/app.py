import os
import sys
from pathlib import Path

# Ensure project root in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from flask import Flask, jsonify, render_template
from flask_cors import CORS
from config.settings import Config
from src.api.routes import api_bp
from src.logger.audit_logger import AuditLogger


def create_app(config_class=Config) -> Flask:
    template_dir = os.path.join(PROJECT_ROOT, "templates")
    static_dir = os.path.join(PROJECT_ROOT, "static")

    app = Flask(
        __name__,
        template_folder=template_dir,
        static_folder=static_dir,
        static_url_path="/static"
    )
    app.config.from_object(config_class)

    # Enable Cross-Origin Resource Sharing
    CORS(app)

    # Initialize Audit Logger (D2)
    AuditLogger.initialize(db_path=config_class.AUDIT_LOG_DB, jsonl_path=config_class.AUDIT_LOG_FILE)

    # Register API blueprint
    app.register_blueprint(api_bp)

    @app.route("/", methods=["GET"])
    def index():
        """Serves the Web UI Input page (Page 1)."""
        return render_template("index.html")

    @app.route("/result", methods=["GET"])
    def result():
        """Serves the Web UI Output / Validation Result page (Page 2)."""
        return render_template("result.html")

    @app.errorhandler(404)
    def not_found(error):
        return jsonify({"error": "Endpoint not found", "status_code": 404}), 404

    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({"error": "Internal server error", "status_code": 500}), 500

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(host=Config.HOST, port=Config.PORT, debug=Config.DEBUG)
