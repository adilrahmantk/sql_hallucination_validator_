"""
Logging Module (Section 5.3.7)
Structured audit store (D2 in DFD) recording validation outcomes,
query details, timestamps, and hallucination flags for auditability and debugging.
"""
import os
import json
import sqlite3
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional


class AuditLogger:
    """Thread-safe structured audit logger supporting JSONL and SQLite storage."""

    _db_path: str = ""
    _jsonl_path: str = ""
    _initialized: bool = False

    @classmethod
    def initialize(cls, db_path: str = "logs/validation_audit.db", jsonl_path: str = "logs/validation_audit.jsonl"):
        """Initializes audit database table and file paths."""
        cls._db_path = db_path
        cls._jsonl_path = jsonl_path

        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        os.makedirs(os.path.dirname(os.path.abspath(jsonl_path)), exist_ok=True)

        conn = sqlite3.connect(cls._db_path)
        cursor = conn.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS validation_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                sql_query TEXT NOT NULL,
                dialect TEXT NOT NULL,
                status TEXT NOT NULL,
                is_valid INTEGER NOT NULL,
                hallucination_count INTEGER NOT NULL,
                hallucinations_json TEXT,
                execution_time_ms REAL,
                client_ip TEXT
            );
            """
        )
        conn.commit()
        conn.close()
        cls._initialized = True

    @classmethod
    def log_validation(
        cls,
        sql_query: str,
        dialect: str,
        status: str,
        is_valid: bool,
        hallucinations: List[Dict[str, Any]],
        execution_time_ms: float = 0.0,
        client_ip: str = "127.0.0.1",
    ):
        """Records a validation attempt to JSONL and SQLite audit store."""
        if not cls._initialized:
            cls.initialize()

        now_str = datetime.now(timezone.utc).isoformat()
        hallucinations_json = json.dumps(hallucinations)

        try:
            conn = sqlite3.connect(cls._db_path)
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO validation_logs (
                    timestamp, sql_query, dialect, status, is_valid,
                    hallucination_count, hallucinations_json, execution_time_ms, client_ip
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
                """,
                (
                    now_str,
                    sql_query,
                    dialect,
                    status,
                    1 if is_valid else 0,
                    len(hallucinations),
                    hallucinations_json,
                    execution_time_ms,
                    client_ip,
                ),
            )
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"[AuditLogger Error] Failed to write to SQLite audit log: {e}")

        try:
            entry = {
                "timestamp": now_str,
                "sql_query": sql_query,
                "dialect": dialect,
                "status": status,
                "is_valid": is_valid,
                "hallucination_count": len(hallucinations),
                "hallucinations": hallucinations,
                "execution_time_ms": execution_time_ms,
                "client_ip": client_ip,
            }
            with open(cls._jsonl_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + chr(10))
        except Exception as e:
            print(f"[AuditLogger Error] Failed to write to JSONL log: {e}")

    @classmethod
    def get_logs(cls, limit: int = 50, status: Optional[str] = None, offset: int = 0) -> List[Dict[str, Any]]:
        """Retrieves recent validation audit records from the audit database."""
        if not cls._initialized:
            cls.initialize()

        conn = sqlite3.connect(cls._db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        if status:
            cursor.execute(
                "SELECT * FROM validation_logs WHERE status = ? ORDER BY id DESC LIMIT ? OFFSET ?;",
                (status.upper(), limit, offset),
            )
        else:
            cursor.execute(
                "SELECT * FROM validation_logs ORDER BY id DESC LIMIT ? OFFSET ?;",
                (limit, offset),
            )

        rows = cursor.fetchall()
        results = []
        for r in rows:
            d = dict(r)
            try:
                d["hallucinations"] = json.loads(d.get("hallucinations_json") or "[]")
            except Exception:
                d["hallucinations"] = []
            d.pop("hallucinations_json", None)
            d["is_valid"] = bool(d.get("is_valid"))
            results.append(d)

        cursor.close()
        conn.close()
        return results
