"""
Decision Engine Module (Section 5.3.6)
Evaluates validation results, determines execution policy (allow vs. block),
safely executes valid queries, and builds structured diagnostic error reports.
"""
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from ..validator.db_connector import DatabaseConnector


@dataclass
class ValidationResult:
    """Structured response object containing validation and execution status."""
    status: str  # "VALID" or "BLOCKED"
    is_valid: bool
    dialect: str
    extracted_elements: Dict[str, Any] = field(default_factory=dict)
    hallucinations: List[Dict[str, Any]] = field(default_factory=list)
    message: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    execution_data: Optional[List[Dict[str, Any]]] = None
    row_count: Optional[int] = None
    execution_error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        res = asdict(self)
        if self.execution_data is None:
            res.pop("execution_data")
        if self.row_count is None:
            res.pop("row_count")
        if self.execution_error is None:
            res.pop("execution_error")
        return res


class DecisionEngine:
    """Evaluates validation findings and governs query execution."""

    @classmethod
    def evaluate(
        cls,
        sql_query: str,
        dialect: str,
        extracted_elements: Dict[str, Any],
        hallucinations: List[Dict[str, Any]],
        syntax_error: Optional[str] = None,
        execute_if_valid: bool = False,
        db_config: Optional[Dict[str, Any]] = None,
    ) -> ValidationResult:
        """
        Processes validation outcome and makes execution decision.
        """
        all_errors = list(hallucinations)

        if syntax_error:
            all_errors.insert(0, {
                "type": "SYNTAX_ERROR",
                "element": None,
                "table": None,
                "error_message": syntax_error,
                "suggestion": "Check SQL syntax, reserved keywords, and matching parentheses.",
            })

        if all_errors:
            count = len(all_errors)
            msg = f"Query execution blocked due to {count} detected schema hallucination(s) / error(s)."
            return ValidationResult(
                status="BLOCKED",
                is_valid=False,
                dialect=dialect,
                extracted_elements=extracted_elements,
                hallucinations=all_errors,
                message=msg,
            )

        msg = "Query passed all deterministic schema validation checks."
        exec_data = None
        row_count = None
        exec_error = None

        if execute_if_valid and db_config:
            data, err = DatabaseConnector.execute_query(db_config, sql_query)
            if err:
                exec_error = err
                msg = f"Validation passed, but database execution failed: {err}"
            else:
                exec_data = data
                row_count = len(data) if data is not None else 0
                msg = f"Query validated and executed successfully. Retrieved {row_count} row(s)."

        return ValidationResult(
            status="VALID",
            is_valid=True,
            dialect=dialect,
            extracted_elements=extracted_elements,
            hallucinations=[],
            message=msg,
            execution_data=exec_data,
            row_count=row_count,
            execution_error=exec_error,
        )
