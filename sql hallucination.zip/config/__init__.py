"""Configuration package for SQL Hallucination Validator."""
