"""
Application Configuration Module.
Strictly scoped to the mini_project_adil specification:
Primary targets: MySQL and PostgreSQL.
Optional local testing: SQLite.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent

# Load environment variables from .env file
load_dotenv(os.path.join(BASE_DIR, ".env"))

class Config:
    """Application settings configuration."""
    SECRET_KEY = os.getenv("SECRET_KEY", "sql-hallucination-validator-secret-key-2026")
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", "5000"))
    DEBUG = os.getenv("FLASK_DEBUG", "1") == "1"

    # Database Defaults (Primary: MySQL / PostgreSQL; Local test: SQLite)
    DEFAULT_DB_TYPE = os.getenv("DEFAULT_DB_TYPE", "sqlite")
    DEFAULT_SQLITE_PATH = os.path.join(BASE_DIR, "database", "demo_enterprise.db")
    
    # Audit Logging Store (D2 in DFD)
    LOGS_DIR = os.path.join(BASE_DIR, "logs")
    AUDIT_LOG_FILE = os.path.join(LOGS_DIR, "validation_audit.jsonl")
    AUDIT_LOG_DB = os.path.join(LOGS_DIR, "validation_audit.db")

    # Schema Cache TTL in seconds
    SCHEMA_CACHE_TTL = int(os.getenv("SCHEMA_CACHE_TTL", "300"))

    # LLM Integration
    LLM_PROVIDER = os.getenv("LLM_PROVIDER", "mock").lower()
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
    GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-flash-lite-latest")

    # Strictly supported dialects per specification
    SUPPORTED_DIALECTS = ["mysql", "postgres", "sqlite"]
