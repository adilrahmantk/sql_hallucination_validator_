// Page 1: Input Page Script
document.addEventListener("DOMContentLoaded", () => {
    const promptInput = document.getElementById("promptInput");
    const dialectSelect = document.getElementById("dialectSelect");
    const btnGenerate = document.getElementById("btnGenerate");
    const btnClear = document.getElementById("btnClear");
    const inputErrorAlert = document.getElementById("inputErrorAlert");
    const inputErrorMessage = document.getElementById("inputErrorMessage");
    const loadingState = document.getElementById("loadingState");

    // 1. Restore previous input from sessionStorage if present
    try {
        const savedInput = sessionStorage.getItem("sql_validation_input");
        if (savedInput) {
            const parsed = JSON.parse(savedInput);
            if (parsed.prompt) promptInput.value = parsed.prompt;
            if (parsed.dialect) dialectSelect.value = parsed.dialect;
        }
    } catch (e) {
        console.warn("Failed to restore input:", e);
    }

    // 2. Sample prompt chips
    document.querySelectorAll(".chip").forEach(chip => {
        chip.addEventListener("click", () => {
            promptInput.value = chip.getAttribute("data-prompt");
            hideError();
            promptInput.focus();
        });
    });

    // 3. Clear button
    btnClear.addEventListener("click", () => {
        promptInput.value = "";
        hideError();
        promptInput.focus();
    });

    promptInput.addEventListener("input", () => {
        if (promptInput.value.trim()) {
            hideError();
        }
    });

    function showError(msg) {
        inputErrorMessage.textContent = msg;
        inputErrorAlert.classList.remove("hidden");
    }

    function hideError() {
        inputErrorAlert.classList.add("hidden");
    }

    // 4. Generate & Validate submission
    btnGenerate.addEventListener("click", async () => {
        const prompt = promptInput.value.trim();
        if (!prompt) {
            showError("Please enter a natural language question.");
            promptInput.focus();
            return;
        }

        const dialect = dialectSelect.value;
        hideError();

        loadingState.classList.remove("hidden");
        btnGenerate.disabled = true;
        btnClear.disabled = true;

        try {
            sessionStorage.setItem("sql_validation_input", JSON.stringify({ prompt, dialect }));

            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 60000); // 60s timeout

            const response = await fetch("/api/v1/generate-and-validate", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ prompt: prompt, dialect: dialect }),
                signal: controller.signal
            });
            clearTimeout(timeoutId);

            let data = null;
            const contentType = response.headers.get("content-type");
            if (contentType && contentType.includes("application/json")) {
                data = await response.json();
            } else {
                const text = await response.text();
                throw new Error(`Server returned non-JSON response (${response.status}): ` + text.substring(0, 100));
            }
            
            // If the server returned a structured decision or error payload, navigate to result
            if (data && data.status) {
                sessionStorage.setItem("sql_validation_result", JSON.stringify(data));
                window.location.href = "/result";
                return;
            }

            if (!response.ok) {
                throw new Error((data && (data.message || data.error)) || `HTTP Error ${response.status}`);
            }

            sessionStorage.setItem("sql_validation_result", JSON.stringify(data));
            window.location.href = "/result";
        } catch (err) {
            console.error("Validation request failed:", err);
            loadingState.classList.add("hidden");
            btnGenerate.disabled = false;
            btnClear.disabled = false;
            
            let errMsg = err.message;
            if (err.name === 'AbortError') {
                errMsg = "Request timed out after 60 seconds. The LLM provider took too long to respond. Please check your network connection or retry.";
            }
            showError("Network or server error connecting to validator: " + errMsg);
        }
    });
});