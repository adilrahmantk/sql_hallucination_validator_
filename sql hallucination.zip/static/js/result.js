// Page 2: Output / Validation Result Script
document.addEventListener("DOMContentLoaded", () => {
    const noResultSection = document.getElementById("noResultSection");
    const resultSection = document.getElementById("resultSection");

    const statusBanner = document.getElementById("statusBanner");
    const statusBadge = document.getElementById("statusBadge");
    const statusDecisionBadge = document.getElementById("statusDecisionBadge");
    const statusDialectBadge = document.getElementById("statusDialectBadge");
    const statusTitle = document.getElementById("statusTitle");
    const statusMessage = document.getElementById("statusMessage");

    const promptDisplay = document.getElementById("promptDisplay");
    const sqlDisplay = document.getElementById("sqlDisplay");
    const btnCopySql = document.getElementById("btnCopySql");

    const metaProvider = document.getElementById("metaProvider");
    const metaModel = document.getElementById("metaModel");
    const metaDialect = document.getElementById("metaDialect");

    const dbResultsCard = document.getElementById("dbResultsCard");
    const dbRowCountBadge = document.getElementById("dbRowCountBadge");
    const dbResultsContainer = document.getElementById("dbResultsContainer");

    const hallucinationsCard = document.getElementById("hallucinationsCard");
    const hallucinationCount = document.getElementById("hallucinationCount");
    const hallucinationsList = document.getElementById("hallucinationsList");

    const validElementsList = document.getElementById("validElementsList");
    const invalidElementsList = document.getElementById("invalidElementsList");

    const astTables = document.getElementById("astTables");
    const astColumns = document.getElementById("astColumns");
    const astAliases = document.getElementById("astAliases");
    const astJoins = document.getElementById("astJoins");
    const astConditions = document.getElementById("astConditions");

    let data = null;
    try {
        const rawResult = sessionStorage.getItem("sql_validation_result");
        if (rawResult) {
            data = JSON.parse(rawResult);
        }
    } catch (e) {
        console.error("Failed to parse validation result from sessionStorage:", e);
    }

    if (!data) {
        noResultSection.classList.remove("hidden");
        resultSection.classList.add("hidden");
        return;
    }

    noResultSection.classList.add("hidden");
    resultSection.classList.remove("hidden");

    renderValidationResult(data);

    if (btnCopySql) {
        btnCopySql.addEventListener("click", () => {
            const sql = sqlDisplay.textContent;
            if (!sql) return;
            navigator.clipboard.writeText(sql).then(() => {
                btnCopySql.textContent = "✓ Copied!";
                setTimeout(() => { btnCopySql.textContent = "📋 Copy SQL"; }, 2000);
            });
        });
    }

    function renderValidationResult(data) {
        const isValid = data.is_valid === true && data.status === "VALID";
        const dialect = data.dialect || (data.validation && data.validation.dialect) || "sqlite";

        if (isValid) {
            statusBanner.className = "status-banner banner-valid";
            statusBadge.textContent = "APPROVED";
            statusDecisionBadge.textContent = "DECISION: APPROVED";
            statusDecisionBadge.className = "badge-pill text-success";
            statusTitle.textContent = "Query Passed Live Schema Validation";
            statusMessage.textContent = data.message || "Query passed all deterministic schema validation checks.";
        } else if (data.status === "ERROR") {
            statusBanner.className = "status-banner banner-blocked";
            statusBadge.textContent = "ERROR";
            statusDecisionBadge.textContent = "DECISION: NOT EXECUTED (ERROR)";
            statusDecisionBadge.className = "badge-pill text-danger";
            statusTitle.textContent = "LLM Generation / Middleware Notice";
            statusMessage.textContent = data.message || "An error occurred during LLM processing.";
        } else {
            statusBanner.className = "status-banner banner-blocked";
            statusBadge.textContent = "BLOCKED";
            statusDecisionBadge.textContent = "DECISION: BLOCKED";
            statusDecisionBadge.className = "badge-pill text-danger";
            statusTitle.textContent = "Execution Blocked (Schema Hallucination Detected)";
            statusMessage.textContent = data.message || "Query execution blocked due to detected schema hallucinations or syntax errors.";
        }

        statusDialectBadge.textContent = "DIALECT: " + dialect.toUpperCase();

        promptDisplay.textContent = data.prompt || "(No prompt text recorded)";
        sqlDisplay.textContent = data.generated_sql || "-- No SQL generated";

        if (data.llm_metadata) {
            metaProvider.textContent = data.llm_metadata.provider || "gemini";
            const actualModel = (data.llm_metadata.metadata && data.llm_metadata.metadata.used_model) || data.llm_metadata.model || "gemini-flash-lite-latest";
            metaModel.textContent = actualModel;
        } else {
            metaProvider.textContent = "gemini";
            metaModel.textContent = "gemini-flash-lite-latest";
        }
        metaDialect.textContent = dialect;

        // Render Database Execution Results
        const execution = data.execution || {};
        if (dbResultsCard && dbResultsContainer && dbRowCountBadge) {
            if (execution && execution.executed && execution.status === "SUCCESS") {
                dbResultsCard.classList.remove("hidden");
                const count = execution.row_count !== undefined && execution.row_count !== null
                    ? execution.row_count
                    : (execution.rows ? execution.rows.length : 0);
                dbRowCountBadge.textContent = count + (count === 1 ? " row returned" : " rows returned");
                dbRowCountBadge.className = "badge-pill text-success";

                if (execution.rows && execution.rows.length > 0) {
                    let tableHtml = '<table class="data-table"><thead><tr>';
                    (execution.columns || []).forEach(col => {
                        tableHtml += '<th>' + escapeHtml(col) + '</th>';
                    });
                    tableHtml += '</tr></thead><tbody>';
                    execution.rows.forEach(row => {
                        tableHtml += '<tr>';
                        (row || []).forEach(val => {
                            const cellText = val !== null && val !== undefined ? String(val) : '<null>';
                            tableHtml += '<td>' + escapeHtml(cellText) + '</td>';
                        });
                        tableHtml += '</tr>';
                    });
                    tableHtml += '</tbody></table>';
                    dbResultsContainer.innerHTML = tableHtml;
                } else {
                    dbResultsContainer.innerHTML = '<div class="empty-results-msg">0 rows returned (Empty result set).</div>';
                }
            } else if (execution && execution.status === "FAILED") {
                dbResultsCard.classList.remove("hidden");
                dbRowCountBadge.textContent = "Execution Failed";
                dbRowCountBadge.className = "badge-pill text-danger";
                dbResultsContainer.innerHTML = '<div class="error-results-msg">⚠️ Execution Error: ' + escapeHtml(execution.error || "Unknown database error.") + '</div>';
            } else {
                // Blocked or not executed
                dbResultsCard.classList.remove("hidden");
                dbRowCountBadge.textContent = "NOT EXECUTED";
                dbRowCountBadge.className = "badge-pill text-muted";
                dbResultsContainer.innerHTML = '<div class="blocked-results-msg">Query validation was BLOCKED. Database execution was safely skipped.</div>';
            }
        }

        const hallucinations = data.hallucinations || [];
        if (hallucinations.length > 0) {
            hallucinationsCard.classList.remove("hidden");
            hallucinationCount.textContent = hallucinations.length;
            hallucinationsList.innerHTML = hallucinations.map(h => {
                let elemHtml = h.element ? '<span class="h-elem">Element: ' + escapeHtml(h.element) + '</span>' : '';
                let suggHtml = h.suggestion ? '<div class="h-suggestion">💡 Suggestion: ' + escapeHtml(h.suggestion) + '</div>' : '';
                return '<div class="hallucination-item"><div class="h-header"><span class="h-type">' + escapeHtml(h.type || "ERROR") + '</span>' + elemHtml + '</div><p class="h-msg">' + escapeHtml(h.error_message || "") + '</p>' + suggHtml + '</div>';
            }).join('');
        } else {
            hallucinationsCard.classList.add("hidden");
            hallucinationsList.innerHTML = '';
        }

        const elements = data.extracted_elements || (data.validation && data.validation.extracted_elements) || {};

        const tables = elements.tables || [];
        if (tables.length > 0) {
            astTables.innerHTML = tables.map(t => {
                const name = typeof t === "object" ? t.name : t;
                const isCte = typeof t === "object" && t.is_cte;
                return '<span class="ast-pill ast-pill-table">' + escapeHtml(name) + (isCte ? ' (CTE)' : '') + '</span>';
            }).join('');
        } else {
            astTables.innerHTML = '<span class="text-muted">None</span>';
        }

        const columns = elements.columns || [];
        if (columns.length > 0) {
            astColumns.innerHTML = columns.map(c => {
                const name = typeof c === "object" ? (c.table_name ? c.table_name + '.' : '') + c.name + ' (' + (c.clause || 'SELECT') + ')' : c;
                return '<span class="ast-pill ast-pill-col">' + escapeHtml(name) + '</span>';
            }).join('');
        } else {
            astColumns.innerHTML = '<span class="text-muted">None</span>';
        }

        const aliases = elements.aliases || {};
        const aliasKeys = Object.keys(aliases);
        if (aliasKeys.length > 0) {
            astAliases.innerHTML = aliasKeys.map(k => '<span class="ast-pill">' + escapeHtml(k) + ' → ' + escapeHtml(aliases[k]) + '</span>').join('');
        } else {
            astAliases.innerHTML = '<span class="text-muted">None</span>';
        }

        const joins = elements.joins || [];
        if (joins.length > 0) {
            astJoins.innerHTML = joins.map(j => {
                const text = typeof j === "object" ? (j.left_table || '') + ' ⇄ ' + (j.right_table || '') + ' (' + (j.join_type || 'INNER') + ' ON ' + (j.condition_raw || '') + ')' : j;
                return '<span class="ast-pill">' + escapeHtml(text) + '</span>';
            }).join('');
        } else {
            astJoins.innerHTML = '<span class="text-muted">None</span>';
        }

        const conditions = elements.conditions || [];
        if (conditions.length > 0) {
            astConditions.innerHTML = conditions.map(c => {
                const text = typeof c === "object" ? c.clause_type + ': ' + c.raw_expression : c;
                return '<span class="ast-pill">' + escapeHtml(text) + '</span>';
            }).join('');
        } else {
            astConditions.innerHTML = '<span class="text-muted">None</span>';
        }

        const invalidTableNames = new Set(hallucinations.filter(h => h.type === "NON_EXISTENT_TABLE").map(h => (h.element || h.table || "").toLowerCase()));
        const invalidColNames = new Set(hallucinations.filter(h => h.type === "NON_EXISTENT_COLUMN").map(h => (h.element || "").toLowerCase()));

        let validHtml = '';
        let invalidHtml = '';

        tables.forEach(t => {
            const name = typeof t === "object" ? t.name : t;
            if (invalidTableNames.has(name.toLowerCase())) {
                invalidHtml += '<span class="ast-pill ast-pill-err">Table: ' + escapeHtml(name) + ' (Not in DB)</span>';
            } else {
                validHtml += '<span class="ast-pill ast-pill-table">Table: ' + escapeHtml(name) + '</span>';
            }
        });

        columns.forEach(c => {
            const name = typeof c === "object" ? c.name : c;
            const full = typeof c === "object" && c.table_name ? c.table_name + '.' + c.name : name;
            if (invalidColNames.has(name.toLowerCase()) || invalidColNames.has(full.toLowerCase())) {
                invalidHtml += '<span class="ast-pill ast-pill-err">Column: ' + escapeHtml(full) + ' (Not in Table)</span>';
            } else {
                validHtml += '<span class="ast-pill ast-pill-col">Column: ' + escapeHtml(full) + '</span>';
            }
        });

        validElementsList.innerHTML = validHtml || '<span class="text-muted">No verified elements</span>';
        invalidElementsList.innerHTML = invalidHtml || '<span class="text-success">None (All elements exist in schema)</span>';
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }
});