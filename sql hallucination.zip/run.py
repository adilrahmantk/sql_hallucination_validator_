import os
import sys
from pathlib import Path

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.app import create_app
from config.settings import Config

app = create_app(Config)

if __name__ == "__main__":
    print(f"============================================================")
    print(f" SQL Hallucination Validator for AI Assistants")
    print(f" Server running on http://127.0.0.1:{Config.PORT}")
    print(f" Health check: http://127.0.0.1:{Config.PORT}/api/v1/health")
    print(f"============================================================")
    app.run(host=Config.HOST, port=Config.PORT, debug=False)
