import pytest
from src.decision.decision_engine import DecisionEngine


def test_decision_engine_block():
    hallucinations = [{
        "type": "NON_EXISTENT_TABLE",
        "element": "clients",
        "table": "clients",
        "error_message": "Table 'clients' does not exist.",
        "suggestion": "Available tables: ['customers', 'orders']"
    }]
    res = DecisionEngine.evaluate(
        sql_query="SELECT * FROM clients",
        dialect="mysql",
        extracted_elements={},
        hallucinations=hallucinations,
    )
    assert res.status == "BLOCKED"
    assert res.is_valid is False
    assert len(res.hallucinations) == 1


def test_decision_engine_allow():
    res = DecisionEngine.evaluate(
        sql_query="SELECT name FROM customers",
        dialect="mysql",
        extracted_elements={"tables": ["customers"]},
        hallucinations=[],
    )
    assert res.status == "VALID"
    assert res.is_valid is True
    assert len(res.hallucinations) == 0
