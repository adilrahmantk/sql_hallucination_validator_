import pytest
from src.parser.ast_parser import ASTParser
from src.extractor.schema_extractor import SchemaExtractor


def test_extract_tables_and_columns():
    sql = """
    SELECT c.name, o.total_amount 
    FROM customers c 
    JOIN orders o ON c.id = o.customer_id 
    WHERE o.status = 'COMPLETED' AND c.country = 'USA'
    """
    ast, _ = ASTParser.parse(sql, "mysql")
    elements = SchemaExtractor.extract(ast, "mysql")

    table_names = [t.name.lower() for t in elements.tables]
    assert "customers" in table_names
    assert "orders" in table_names

    col_tuples = [(c.name.lower(), c.table_name.lower() if c.table_name else None) for c in elements.columns]
    assert ("name", "customers") in col_tuples
    assert ("total_amount", "orders") in col_tuples
    assert ("status", "orders") in col_tuples

    assert len(elements.joins) == 1
    assert elements.joins[0].left_table.lower() == "customers"
    assert elements.joins[0].right_table.lower() == "orders"
