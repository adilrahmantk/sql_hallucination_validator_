import pytest
import os
from unittest.mock import patch, MagicMock
from src.llm.gemini_provider import GeminiLLMProvider
from config.settings import Config
from src.llm.base import LLMResponse


@patch("src.llm.gemini_provider.types")
@patch("src.llm.gemini_provider.genai")
def test_gemini_provider_missing_api_key(mock_genai, mock_types):
    """Test that missing API key raises ValueError."""
    Config.GEMINI_API_KEY = None
    with pytest.raises(ValueError, match="GEMINI_API_KEY environment variable is missing."):
        GeminiLLMProvider()

@patch("src.llm.gemini_provider.types")
@patch("src.llm.gemini_provider.genai")
def test_gemini_provider_success(mock_genai, mock_types):
    """Test successful SQL generation with Gemini."""
    Config.GEMINI_API_KEY = "dummy_key"
    
    mock_client = MagicMock()
    mock_genai.Client.return_value = mock_client
    
    mock_response = MagicMock()
    mock_response.text = "```sql\nSELECT * FROM users;\n```"
    mock_client.models.generate_content.return_value = mock_response

    provider = GeminiLLMProvider()
    response = provider.generate_sql("Show all users")
    
    assert isinstance(response, LLMResponse)
    assert response.sql_query == "SELECT * FROM users;"
    assert response.provider == "gemini"

@patch("src.llm.gemini_provider.types")
@patch("src.llm.gemini_provider.genai")
def test_gemini_provider_empty_response(mock_genai, mock_types):
    """Test empty response from Gemini."""
    Config.GEMINI_API_KEY = "dummy_key"
    
    mock_client = MagicMock()
    mock_genai.Client.return_value = mock_client
    
    mock_response = MagicMock()
    mock_response.text = ""
    mock_client.models.generate_content.return_value = mock_response

    provider = GeminiLLMProvider()
    with pytest.raises(ValueError, match="Unable to extract valid SQL from the LLM response."):
        provider.generate_sql("Show all users")

@patch("src.llm.gemini_provider.types")
@patch("src.llm.gemini_provider.genai")
def test_gemini_provider_malformed_response(mock_genai, mock_types):
    """Test malformed response from Gemini without valid SQL block."""
    Config.GEMINI_API_KEY = "dummy_key"
    
    mock_client = MagicMock()
    mock_genai.Client.return_value = mock_client
    
    mock_response = MagicMock()
    mock_response.text = "Here is some text with no SQL."
    mock_client.models.generate_content.return_value = mock_response

    provider = GeminiLLMProvider()
    response = provider.generate_sql("Show all users")
    assert response.sql_query == "Here is some text with no SQL."

@patch("src.llm.gemini_provider.types")
@patch("src.llm.gemini_provider.genai")
def test_gemini_provider_api_error(mock_genai, mock_types):
    """Test API error from Gemini."""
    Config.GEMINI_API_KEY = "dummy_key"
    
    mock_client = MagicMock()
    mock_genai.Client.return_value = mock_client
    mock_client.models.generate_content.side_effect = Exception("API rate limit exceeded")

    provider = GeminiLLMProvider()
    with pytest.raises(RuntimeError, match="LLM generation failed: API rate limit exceeded"):
        provider.generate_sql("Show all users")
