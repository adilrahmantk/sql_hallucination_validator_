import pytest
from src.parser.ast_parser import ASTParser
from src.extractor.schema_extractor import SchemaExtractor
from src.validator.schema_validator import SchemaValidator

sample_live_schema = {
    "tables": ["customers", "orders", "products"],
    "columns": {
        "customers": {"id": {}, "name": {}, "email": {}, "country": {}},
        "orders": {"id": {}, "customer_id": {}, "total_amount": {}, "status": {}},
        "products": {"id": {}, "product_name": {}, "unit_price": {}},
    },
    "relationships": [
        {"table": "orders", "column": "customer_id", "ref_table": "customers", "ref_column": "id"}
    ]
}


def test_valid_query_passes():
    sql = "SELECT c.name, o.total_amount FROM customers c JOIN orders o ON c.id = o.customer_id WHERE o.status = 'COMPLETED'"
    ast, _ = ASTParser.parse(sql, "mysql")
    elements = SchemaExtractor.extract(ast, "mysql")
    hallucinations = SchemaValidator.validate(elements, sample_live_schema)
    assert len(hallucinations) == 0


def test_detect_hallucinated_table():
    sql = "SELECT client_name FROM clients"
    ast, _ = ASTParser.parse(sql, "mysql")
    elements = SchemaExtractor.extract(ast, "mysql")
    hallucinations = SchemaValidator.validate(elements, sample_live_schema)
    assert len(hallucinations) > 0
    assert any(h["type"] == "NON_EXISTENT_TABLE" and h["element"] == "clients" for h in hallucinations)


def test_detect_hallucinated_column():
    sql = "SELECT c.invalid_col, c.name FROM customers c"
    ast, _ = ASTParser.parse(sql, "mysql")
    elements = SchemaExtractor.extract(ast, "mysql")
    hallucinations = SchemaValidator.validate(elements, sample_live_schema)
    assert len(hallucinations) == 1
    assert hallucinations[0]["type"] == "NON_EXISTENT_COLUMN"
    assert hallucinations[0]["element"] == "invalid_col"
