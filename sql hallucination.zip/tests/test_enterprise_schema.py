"""
Validation and Demonstration Test Script for the Expanded 20-Table Enterprise Database.
Tests:
1. Live schema extraction from SQLite
2. Valid queries across single table, multi-table joins, aggregations, GROUP BY, HAVING, ORDER BY, subqueries
3. Hallucinated tables
4. Hallucinated columns
5. Invalid JOINs / non-existent join keys
6. Decision engine ALLOW vs BLOCK enforcement
"""
import pytest
from src.parser.ast_parser import ASTParser
from src.extractor.schema_extractor import SchemaExtractor
from src.validator.schema_inspector import SchemaInspector
from src.validator.schema_validator import SchemaValidator
from src.decision.decision_engine import DecisionEngine
from config.settings import Config

DB_CONFIG = {
    "db_type": "sqlite",
    "database_path": Config.DEFAULT_SQLITE_PATH,
    "database": "demo_enterprise.db"
}


@pytest.fixture(scope="module")
def live_schema():
    """Fetches live schema dynamically from the SQLite catalog."""
    return SchemaInspector.fetch_live_schema(DB_CONFIG, ttl_seconds=0, force_refresh=True)


def test_live_schema_contains_all_20_tables(live_schema):
    """Verifies that SchemaInspector dynamically extracts all 20 tables from SQLite metadata."""
    expected_tables = {
        "regions", "countries", "customers", "customer_addresses", "departments",
        "employees", "managers", "projects", "employee_projects", "product_categories",
        "suppliers", "products", "warehouses", "inventory", "orders",
        "order_items", "invoices", "payments", "shipments", "product_reviews"
    }
    extracted_tables = set(live_schema["tables"])
    assert expected_tables.issubset(extracted_tables), f"Missing tables: {expected_tables - extracted_tables}"
    assert len(extracted_tables) >= 20


def test_live_schema_has_foreign_key_relationships(live_schema):
    """Verifies that PRAGMA foreign_key_list extracts relationships."""
    relationships = live_schema.get("relationships", [])
    assert len(relationships) >= 15
    rel_pairs = {(r["table"], r["ref_table"]) for r in relationships}
    assert ("countries", "regions") in rel_pairs
    assert ("employees", "departments") in rel_pairs
    assert ("orders", "customers") in rel_pairs
    assert ("order_items", "orders") in rel_pairs
    assert ("order_items", "products") in rel_pairs
    assert ("shipments", "warehouses") in rel_pairs


# -----------------------------------------------------------------
# Valid Query Tests
# -----------------------------------------------------------------

def test_valid_single_table_query(live_schema):
    sql = "SELECT customer_id, name, email, customer_status FROM customers WHERE customer_status = 'ACTIVE' LIMIT 10"
    ast, _ = ASTParser.parse(sql, "sqlite")
    elems = SchemaExtractor.extract(ast, "sqlite")
    errors = SchemaValidator.validate(elems, live_schema)
    assert len(errors) == 0


def test_valid_two_table_join(live_schema):
    sql = """
    SELECT e.first_name, e.last_name, e.salary, d.dept_name, d.location
    FROM employees e
    JOIN departments d ON e.department_id = d.id
    WHERE e.salary > 80000
    """
    ast, _ = ASTParser.parse(sql, "sqlite")
    elems = SchemaExtractor.extract(ast, "sqlite")
    errors = SchemaValidator.validate(elems, live_schema)
    assert len(errors) == 0


def test_valid_multi_table_join_complex(live_schema):
    sql = """
    SELECT 
        c.name AS customer_name,
        o.order_date,
        p.product_name,
        oi.quantity,
        oi.unit_price,
        s.carrier,
        s.tracking_number
    FROM customers c
    JOIN orders o ON c.id = o.customer_id
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON oi.product_id = p.id
    JOIN shipments s ON o.id = s.order_id
    WHERE o.status = 'COMPLETED'
    ORDER BY o.order_date DESC
    LIMIT 20
    """
    ast, _ = ASTParser.parse(sql, "sqlite")
    elems = SchemaExtractor.extract(ast, "sqlite")
    errors = SchemaValidator.validate(elems, live_schema)
    assert len(errors) == 0


def test_valid_group_by_having_aggregation(live_schema):
    sql = """
    SELECT 
        d.dept_name,
        COUNT(e.id) AS total_employees,
        AVG(e.salary) AS avg_salary
    FROM departments d
    JOIN employees e ON d.id = e.department_id
    GROUP BY d.dept_name
    HAVING AVG(e.salary) > 60000
    ORDER BY AVG(e.salary) DESC
    """
    ast, _ = ASTParser.parse(sql, "sqlite")
    elems = SchemaExtractor.extract(ast, "sqlite")
    errors = SchemaValidator.validate(elems, live_schema)
    assert len(errors) == 0


def test_valid_nested_subquery_and_date_filter(live_schema):
    sql = """
    SELECT p.product_name, p.unit_price, p.stock_quantity
    FROM products p
    WHERE p.id IN (
        SELECT oi.product_id
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.id
        WHERE o.order_date >= '2023-01-01'
    )
    """
    ast, _ = ASTParser.parse(sql, "sqlite")
    elems = SchemaExtractor.extract(ast, "sqlite")
    errors = SchemaValidator.validate(elems, live_schema)
    assert len(errors) == 0


# -----------------------------------------------------------------
# Hallucination Tests (Must be Blocked)
# -----------------------------------------------------------------

def test_hallucinated_table_blocked(live_schema):
    sql = "SELECT client_id, billing_total FROM enterprise_clients WHERE account_type = 'ENTERPRISE'"
    ast, _ = ASTParser.parse(sql, "sqlite")
    elems = SchemaExtractor.extract(ast, "sqlite")
    errors = SchemaValidator.validate(elems, live_schema)
    assert len(errors) >= 1
    assert any(e["type"] == "NON_EXISTENT_TABLE" and e["element"] == "enterprise_clients" for e in errors)
    decision = DecisionEngine.evaluate(sql, "sqlite", elems.to_dict(), errors)
    assert decision.status == "BLOCKED"
    assert decision.is_valid is False


def test_hallucinated_column_blocked(live_schema):
    sql = "SELECT c.id, c.name, c.telephone_number, c.social_security_number FROM customers c"
    ast, _ = ASTParser.parse(sql, "sqlite")
    elems = SchemaExtractor.extract(ast, "sqlite")
    errors = SchemaValidator.validate(elems, live_schema)
    assert len(errors) >= 2
    assert any(e["type"] == "NON_EXISTENT_COLUMN" and e["element"] == "telephone_number" for e in errors)
    assert any(e["type"] == "NON_EXISTENT_COLUMN" and e["element"] == "social_security_number" for e in errors)
    decision = DecisionEngine.evaluate(sql, "sqlite", elems.to_dict(), errors)
    assert decision.status == "BLOCKED"
    assert decision.is_valid is False


def test_hallucinated_join_relationship_blocked(live_schema):
    # Joining orders and employees via hallucinated non-existent employee_code
    sql = """
    SELECT o.id, e.first_name
    FROM orders o
    JOIN employees e ON o.employee_code = e.employee_id
    """
    ast, _ = ASTParser.parse(sql, "sqlite")
    elems = SchemaExtractor.extract(ast, "sqlite")
    errors = SchemaValidator.validate(elems, live_schema)
    assert len(errors) >= 1
    assert any(e["type"] in ("INVALID_JOIN_RELATIONSHIP", "NON_EXISTENT_COLUMN") for e in errors)
    decision = DecisionEngine.evaluate(sql, "sqlite", elems.to_dict(), errors)
    assert decision.status == "BLOCKED"


def test_safe_execution_of_valid_query(live_schema):
    sql = "SELECT id, product_name, unit_price FROM products WHERE unit_price > 1000 LIMIT 3"
    ast, _ = ASTParser.parse(sql, "sqlite")
    elems = SchemaExtractor.extract(ast, "sqlite")
    errors = SchemaValidator.validate(elems, live_schema)
    assert len(errors) == 0
    decision = DecisionEngine.evaluate(
        sql, "sqlite", elems.to_dict(), errors, execute_if_valid=True, db_config=DB_CONFIG
    )
    assert decision.status == "VALID"
    assert decision.is_valid is True
    assert decision.execution_data is not None
    assert decision.row_count > 0
    assert len(decision.execution_data) == decision.row_count
