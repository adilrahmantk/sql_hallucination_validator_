import pytest
from src.preprocessor.preprocessor import QueryPreprocessor


def test_clean_and_preserve_literals():
    sql = "SELECT c.id FROM customers c WHERE c.name = 'John -- not a comment' -- real comment;"
    cleaned = QueryPreprocessor.clean(sql)
    assert "John -- not a comment" in cleaned
    assert "real comment" not in cleaned
    assert not cleaned.endswith(";")


def test_strip_markdown_fences():
    sql = "```sql\nSELECT * FROM customers\n```"
    cleaned = QueryPreprocessor.clean(sql)
    assert "```" not in cleaned
    assert "SELECT * FROM customers" in cleaned


def test_dialect_detection():
    assert QueryPreprocessor.detect_dialect("Postgres") == "postgres"
    assert QueryPreprocessor.detect_dialect("postgresql") == "postgres"
    assert QueryPreprocessor.detect_dialect("mysql") == "mysql"
    assert QueryPreprocessor.detect_dialect("sqlite") == "sqlite"
    assert QueryPreprocessor.detect_dialect(None, "SELECT * FROM t WHERE col ILIKE '%test%'") == "postgres"
    assert QueryPreprocessor.detect_dialect(None, "SELECT * FROM `users`") == "mysql"


def test_empty_query():
    norm, dialect, err = QueryPreprocessor.process("")
    assert err is not None
    assert "Empty" in err


def test_invalid_keyword():
    norm, dialect, err = QueryPreprocessor.process("DROPZONE * FROM t")
    assert err is not None
    assert "valid SQL statement keyword" in err
