import pytest
from src.parser.ast_parser import ASTParser


def test_parse_valid_query():
    sql = "SELECT id, name FROM customers WHERE country = 'USA'"
    ast, err = ASTParser.parse(sql, "mysql")
    assert err is None
    assert ast is not None


def test_parse_syntax_error():
    sql = "SELECT FROM WHERE"
    ast, err = ASTParser.parse(sql, "mysql")
    assert err is not None
    assert "Syntax / Parsing Error" in err


def test_table_alias_map():
    sql = "SELECT c.name, o.id FROM customers c JOIN orders o ON c.id = o.customer_id"
    ast, _ = ASTParser.parse(sql, "mysql")
    alias_map = ASTParser.get_table_alias_map(ast)
    assert alias_map.get("c") == "customers"
    assert alias_map.get("o") == "orders"


def test_cte_extraction():
    sql = "WITH regional_sales AS (SELECT * FROM orders) SELECT * FROM regional_sales"
    ast, _ = ASTParser.parse(sql, "mysql")
    ctes = ASTParser.get_cte_names(ast)
    assert "regional_sales" in ctes
