import pytest
from src.parser.ast_parser import ASTParser
from src.extractor.schema_extractor import SchemaExtractor
from src.validator.schema_validator import SchemaValidator

schema = {
    "tables": ["customers", "orders", "order_items", "products", "departments", "employees"],
    "columns": {
        "customers": {"id": {}, "name": {}, "email": {}, "country": {}},
        "departments": {"id": {}, "dept_name": {}, "budget": {}},
        "employees": {"id": {}, "first_name": {}, "last_name": {}, "department_id": {}, "salary": {}},
        "products": {"id": {}, "product_name": {}, "category": {}, "unit_price": {}, "stock_quantity": {}},
        "orders": {"id": {}, "customer_id": {}, "total_amount": {}, "status": {}},
        "order_items": {"id": {}, "order_id": {}, "product_id": {}, "quantity": {}, "unit_price": {}},
    },
    "relationships": [
        {"table": "orders", "column": "customer_id", "ref_table": "customers", "ref_column": "id"},
        {"table": "order_items", "column": "order_id", "ref_table": "orders", "ref_column": "id"},
        {"table": "order_items", "column": "product_id", "ref_table": "products", "ref_column": "id"},
        {"table": "employees", "column": "department_id", "ref_table": "departments", "ref_column": "id"},
    ]
}


def test_hallucination_nonexistent_table():
    sql = "SELECT * FROM client_accounts"
    ast, _ = ASTParser.parse(sql, "mysql")
    elems = SchemaExtractor.extract(ast, "mysql")
    errors = SchemaValidator.validate(elems, schema)
    assert any(e["type"] == "NON_EXISTENT_TABLE" and e["element"] == "client_accounts" for e in errors)


def test_hallucination_nonexistent_column_in_where():
    sql = "SELECT name FROM customers WHERE user_age > 30"
    ast, _ = ASTParser.parse(sql, "mysql")
    elems = SchemaExtractor.extract(ast, "mysql")
    errors = SchemaValidator.validate(elems, schema)
    assert any(e["type"] == "NON_EXISTENT_COLUMN" and e["element"] == "user_age" for e in errors)


def test_hallucination_invalid_join_column():
    sql = "SELECT e.first_name, d.dept_name FROM employees e JOIN departments d ON e.dept_code = d.id"
    ast, _ = ASTParser.parse(sql, "mysql")
    elems = SchemaExtractor.extract(ast, "mysql")
    errors = SchemaValidator.validate(elems, schema)
    assert any(e["type"] == "INVALID_JOIN_RELATIONSHIP" or (e["type"] == "NON_EXISTENT_COLUMN" and e["element"] == "dept_code") for e in errors)


def test_cte_virtual_table_not_hallucinated():
    sql = "WITH top_cust AS (SELECT id, name FROM customers WHERE country = 'USA') SELECT name FROM top_cust"
    ast, _ = ASTParser.parse(sql, "mysql")
    elems = SchemaExtractor.extract(ast, "mysql")
    errors = SchemaValidator.validate(elems, schema)
    # top_cust is a virtual CTE and must not be flagged as non-existent physical table
    assert len(errors) == 0
