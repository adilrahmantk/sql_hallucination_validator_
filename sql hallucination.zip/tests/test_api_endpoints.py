import pytest
import json
from src.app import create_app
from config.settings import Config


@pytest.fixture
def client():
    app = create_app(Config)
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_health_endpoint(client):
    res = client.get("/api/v1/health")
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "healthy"


def test_validate_valid_query(client):
    payload = {
        "sql_query": "SELECT c.name, c.email FROM customers c WHERE c.country = 'USA'",
        "dialect": "sqlite",
        "database_config": {
            "db_type": "sqlite",
            "database_path": Config.DEFAULT_SQLITE_PATH
        }
    }
    res = client.post("/api/v1/validate", json=payload)
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "VALID"
    assert data["is_valid"] is True
    assert len(data["hallucinations"]) == 0


def test_validate_hallucinated_query(client):
    payload = {
        "sql_query": "SELECT c.non_existent_column, c.name FROM customers c",
        "dialect": "sqlite",
        "database_config": {
            "db_type": "sqlite",
            "database_path": Config.DEFAULT_SQLITE_PATH
        }
    }
    res = client.post("/api/v1/validate", json=payload)
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "BLOCKED"
    assert data["is_valid"] is False
    assert len(data["hallucinations"]) >= 1
    assert data["hallucinations"][0]["type"] == "NON_EXISTENT_COLUMN"


def test_validate_and_execute(client):
    payload = {
        "sql_query": "SELECT c.id, c.name FROM customers c WHERE c.country = 'USA'",
        "dialect": "sqlite",
        "database_config": {
            "db_type": "sqlite",
            "database_path": Config.DEFAULT_SQLITE_PATH
        }
    }
    res = client.post("/api/v1/validate-and-execute", json=payload)
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "VALID"
    assert "execution_data" in data
    assert data["row_count"] >= 1


def test_logs_endpoint(client):
    res = client.get("/api/v1/logs?limit=5")
    assert res.status_code == 200
    data = res.get_json()
    assert "logs" in data


def test_generate_and_validate_valid_nl_query(client):
    payload = {
        "prompt": "Show all customers from USA",
        "dialect": "sqlite",
        "database_config": {
            "db_type": "sqlite",
            "database_path": Config.DEFAULT_SQLITE_PATH
        }
    }
    res = client.post("/api/v1/generate-and-validate", json=payload)
    assert res.status_code == 200
    data = res.get_json()
    assert data["prompt"] == "Show all customers from USA"
    assert "generated_sql" in data
    assert "llm_metadata" in data
    assert data["status"] == "VALID"
    assert data["is_valid"] is True
    assert len(data["hallucinations"]) == 0
    assert "extracted_elements" in data
    assert "tables" in data["extracted_elements"]


def test_generate_and_validate_hallucinated_table(client):
    payload = {
        "prompt": "Get all client invoices",
        "dialect": "sqlite",
        "database_config": {
            "db_type": "sqlite",
            "database_path": Config.DEFAULT_SQLITE_PATH
        }
    }
    res = client.post("/api/v1/generate-and-validate", json=payload)
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "BLOCKED"
    assert data["is_valid"] is False
    assert len(data["hallucinations"]) >= 1
    assert any(h["type"] == "NON_EXISTENT_TABLE" for h in data["hallucinations"])


def test_generate_and_validate_hallucinated_column(client):
    payload = {
        "prompt": "Get customer phone numbers",
        "dialect": "sqlite",
        "database_config": {
            "db_type": "sqlite",
            "database_path": Config.DEFAULT_SQLITE_PATH
        }
    }
    res = client.post("/api/v1/generate-and-validate", json=payload)
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "BLOCKED"
    assert data["is_valid"] is False
    assert len(data["hallucinations"]) >= 1
    assert any(h["type"] == "NON_EXISTENT_COLUMN" for h in data["hallucinations"])


def test_generate_and_validate_students_mca_blocked(client):
    payload = {
        "prompt": "Find all STUDENTS IN MCA",
        "dialect": "sqlite",
        "database_config": {
            "db_type": "sqlite",
            "database_path": Config.DEFAULT_SQLITE_PATH
        }
    }
    res = client.post("/api/v1/generate-and-validate", json=payload)
    assert res.status_code == 200
    data = res.get_json()
    assert data["prompt"] == "Find all STUDENTS IN MCA"
    assert data["status"] == "BLOCKED"
    assert data["is_valid"] is False
    assert len(data["hallucinations"]) >= 1
    assert any(h["type"] == "NON_EXISTENT_TABLE" and h["element"] == "students" for h in data["hallucinations"])


def test_generate_and_validate_malformed_payload(client):
    payload = {}
    res = client.post("/api/v1/generate-and-validate", json=payload)
    assert res.status_code == 400
    data = res.get_json()
    assert data["status"] == "BLOCKED"
    assert data["is_valid"] is False
    assert data["hallucinations"][0]["type"] == "REQUEST_VALIDATION_ERROR"


def test_generate_and_validate_with_execution_success(client):
    payload = {
        "prompt": "Show all customers from USA",
        "dialect": "sqlite",
        "database_config": {
            "db_type": "sqlite",
            "database_path": Config.DEFAULT_SQLITE_PATH
        },
        "execute_if_valid": True
    }
    res = client.post("/api/v1/generate-and-validate", json=payload)
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "VALID"
    assert data["is_valid"] is True
    assert "execution" in data
    assert data["execution"]["executed"] is True
    assert data["execution"]["status"] == "SUCCESS"
    assert data["execution"]["row_count"] > 0
    assert len(data["execution"]["rows"]) == data["execution"]["row_count"]
    assert "name" in data["execution"]["columns"]
    assert "email" in data["execution"]["columns"]


def test_generate_and_validate_blocked_execution_not_run(client):
    payload = {
        "prompt": "Find all STUDENTS IN MCA",
        "dialect": "sqlite",
        "database_config": {
            "db_type": "sqlite",
            "database_path": Config.DEFAULT_SQLITE_PATH
        },
        "execute_if_valid": True
    }
    res = client.post("/api/v1/generate-and-validate", json=payload)
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "BLOCKED"
    assert data["is_valid"] is False
    assert "execution" in data
    assert data["execution"]["executed"] is False
    assert data["execution"]["status"] == "NOT_EXECUTED"
    assert data["execution"]["rows"] == []
    assert data["execution"]["row_count"] == 0


def test_generate_and_validate_guarantees_no_execution(client):
    payload = {
        "prompt": "Show all customers from USA",
        "dialect": "sqlite",
        "database_config": {
            "db_type": "sqlite",
            "database_path": Config.DEFAULT_SQLITE_PATH
        },
        "execute_if_valid": False
    }
    res = client.post("/api/v1/generate-and-validate", json=payload)
    assert res.status_code == 200
    data = res.get_json()
    assert data["execution"]["executed"] is False
    assert data["execution"]["status"] == "NOT_EXECUTED"
    assert "execution_data" not in data["validation"] or data["validation"].get("execution_data") is None


def test_ui_index_route(client):
    """Verify that GET / returns the Web UI Input page (Page 1) with status 200."""
    res = client.get("/")
    assert res.status_code == 200
    assert b"SQL Hallucination Validator" in res.data
    assert b"promptInput" in res.data
    assert b"btnGenerate" in res.data
    assert b"Page 1: Input" in res.data


def test_ui_result_route(client):
    """Verify that GET /result returns the Web UI Result page (Page 2) with status 200."""
    res = client.get("/result")
    assert res.status_code == 200
    assert b"SQL Hallucination Validator" in res.data
    assert b"Back to Input" in res.data
    assert b"statusBanner" in res.data
    assert b"sqlDisplay" in res.data
    assert b"dbResultsCard" in res.data
    assert b"dbRowCountBadge" in res.data



def test_ui_static_assets(client):
    """Verify that CSS and JavaScript static assets load with status 200."""
    css_res = client.get("/static/css/styles.css")
    assert css_res.status_code == 200
    assert b"--bg-base" in css_res.data

    input_js_res = client.get("/static/js/input.js")
    assert input_js_res.status_code == 200
    assert b"generate-and-validate" in input_js_res.data

    result_js_res = client.get("/static/js/result.js")
    assert result_js_res.status_code == 200
    assert b"sql_validation_result" in result_js_res.data

    app_js_res = client.get("/static/js/app.js")
    assert app_js_res.status_code == 200
