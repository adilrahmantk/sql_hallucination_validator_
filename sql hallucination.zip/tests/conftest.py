import os
import pytest

# Force tests to use MockLLMProvider by default to avoid making actual API calls
# and to prevent tests failing if .env contains a real provider or invalid key.
os.environ["LLM_PROVIDER"] = "mock"

@pytest.fixture(autouse=True)
def override_config():
    from config.settings import Config
    Config.LLM_PROVIDER = "mock"
