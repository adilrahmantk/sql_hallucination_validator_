import sqlite3

conn = sqlite3.connect("database/demo_enterprise.db")
cursor = conn.cursor()

cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name;")
tables = [r[0] for r in cursor.fetchall()]

print(f"Total tables: {len(tables)}")
print("-" * 50)
total_records = 0
for t in tables:
    cnt = cursor.execute(f"SELECT count(*) FROM {t}").fetchone()[0]
    total_records += cnt
    cols = len(cursor.execute(f"PRAGMA table_info('{t}')").fetchall())
    print(f"  - {t:<22} : {cnt:>6} rows, {cols:>2} columns")

print("-" * 50)
print(f"Total seeded records across all tables: {total_records}")

cursor.execute("PRAGMA foreign_key_check;")
violations = cursor.fetchall()
print(f"Foreign key check violations: {len(violations)}")
if violations:
    print(f"Violations detail: {violations}")

conn.close()
