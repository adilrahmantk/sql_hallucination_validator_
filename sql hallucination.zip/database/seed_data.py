"""
Populates local SQLite demo database with realistic, enterprise-scale relational records
across 20 related tables for the SQL Hallucination Validator project.

Target scales (reproducible seed, fast initialization, zero broken foreign keys):
- regions: 6
- countries: 30
- departments: 12
- employees: 220+
- managers: 24
- customers: 1,100+
- customer_addresses: 1,650+
- projects: 110+
- employee_projects: 350+
- product_categories: 32
- suppliers: 110+
- products: 520+
- warehouses: 22
- inventory: 3,500+
- orders: 5,200+
- order_items: 15,600+
- invoices: 5,200
- payments: 4,800+
- shipments: 5,100+
- product_reviews: 2,500+
"""
import os
import random
import sqlite3
from datetime import datetime, date, timedelta

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "database", "demo_enterprise.db")
SQL_PATH = os.path.join(BASE_DIR, "database", "schema_sqlite.sql")

# Deterministic seed for exact reproducibility across runs
RANDOM_SEED = 42

FIRST_NAMES = [
    "James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael", "Linda",
    "William", "Elizabeth", "David", "Barbara", "Richard", "Susan", "Joseph", "Jessica",
    "Thomas", "Sarah", "Charles", "Karen", "Christopher", "Nancy", "Daniel", "Lisa",
    "Matthew", "Betty", "Anthony", "Margaret", "Mark", "Sandra", "Donald", "Ashley",
    "Steven", "Kimberly", "Paul", "Emily", "Andrew", "Donna", "Joshua", "Michelle",
    "Kenneth", "Dorothy", "Kevin", "Carol", "Brian", "Amanda", "George", "Melissa",
    "Edward", "Deborah", "Ronald", "Stephanie", "Timothy", "Rebecca", "Jason", "Sharon",
    "Jeffrey", "Laura", "Ryan", "Cynthia", "Jacob", "Kathleen", "Gary", "Amy",
    "Nicholas", "Shirley", "Eric", "Angela", "Jonathan", "Helen", "Stephen", "Anna",
    "Larry", "Brenda", "Justin", "Pamela", "Scott", "Nicole", "Brandon", "Emma",
    "Benjamin", "Samantha", "Samuel", "Katherine", "Gregory", "Christine", "Frank", "Debra",
    "Alexander", "Rachel", "Raymond", "Catherine", "Patrick", "Carolyn", "Jack", "Janet",
    "Dennis", "Ruth", "Jerry", "Maria", "Tyler", "Heather", "Aaron", "Diane"
]

LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
    "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
    "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson",
    "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker",
    "Young", "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill",
    "Flores", "Green", "Adams", "Nelson", "Baker", "Hall", "Rivera", "Campbell",
    "Mitchell", "Carter", "Roberts", "Gomez", "Phillips", "Evans", "Turner", "Diaz",
    "Parker", "Cruz", "Edwards", "Collins", "Reyes", "Stewart", "Morris", "Morales",
    "Murphy", "Cook", "Rogers", "Gutierrez", "Ortiz", "Morgan", "Cooper", "Peterson",
    "Bailey", "Reed", "Kelly", "Howard", "Ramos", "Kim", "Cox", "Ward", "Richardson",
    "Watson", "Brooks", "Chavez", "Wood", "James", "Bennett", "Gray", "Mendoza",
    "Ruiz", "Hughes", "Price", "Alvarez", "Castillo", "Sanders", "Patel", "Myers"
]

REGIONS_DATA = [
    ("North America", "NA"),
    ("Europe", "EU"),
    ("Asia-Pacific", "APAC"),
    ("Latin America", "LATAM"),
    ("Middle East & Africa", "MEA"),
    ("Oceania", "OC"),
]

COUNTRIES_DATA = [
    ("United States", "USA", 1),
    ("Canada", "CAN", 1),
    ("Mexico", "MEX", 1),
    ("United Kingdom", "GBR", 2),
    ("Germany", "DEU", 2),
    ("France", "FRA", 2),
    ("Netherlands", "NLD", 2),
    ("Switzerland", "CHE", 2),
    ("Sweden", "SWE", 2),
    ("Spain", "ESP", 2),
    ("Italy", "ITA", 2),
    ("Poland", "POL", 2),
    ("Japan", "JPN", 3),
    ("South Korea", "KOR", 3),
    ("China", "CHN", 3),
    ("India", "IND", 3),
    ("Singapore", "SGP", 3),
    ("Taiwan", "TWN", 3),
    ("Vietnam", "VNM", 3),
    ("Brazil", "BRA", 4),
    ("Argentina", "ARG", 4),
    ("Chile", "CHL", 4),
    ("Colombia", "COL", 4),
    ("United Arab Emirates", "ARE", 5),
    ("Saudi Arabia", "SAU", 5),
    ("South Africa", "ZAF", 5),
    ("Egypt", "EGY", 5),
    ("Australia", "AUS", 6),
    ("New Zealand", "NZL", 6),
    ("Ireland", "IRL", 2),
]

DEPARTMENTS_DATA = [
    ("Engineering", "ENG", 1250000.0, "Building A, Floor 4"),
    ("Sales", "SLS", 850000.0, "Building B, Floor 2"),
    ("Marketing", "MKT", 550000.0, "Building B, Floor 3"),
    ("Human Resources", "HR", 350000.0, "Building A, Floor 2"),
    ("Product Management", "PM", 700000.0, "Building A, Floor 3"),
    ("Customer Support", "SUP", 400000.0, "Building C, Floor 1"),
    ("Finance & Accounting", "FIN", 600000.0, "Building A, Floor 5"),
    ("Supply Chain & Logistics", "LOG", 900000.0, "Logistics Center 1"),
    ("Information Technology", "IT", 800000.0, "Building A, Floor 1"),
    ("Legal & Compliance", "LGL", 300000.0, "Building A, Floor 5"),
    ("Research & Development", "RND", 1100000.0, "Tech Lab East"),
    ("Quality Assurance", "QA", 450000.0, "Building C, Floor 2"),
]

PRODUCT_CATEGORIES_DATA = [
    ("Laptops & Notebooks", "CAT_LAPT", "High-performance portable workstations and ultrabooks"),
    ("Desktop Computers", "CAT_DESK", "Enterprise desktop towers and all-in-one systems"),
    ("Computer Monitors", "CAT_MON", "Ultra-wide, 4K, and professional color-accurate displays"),
    ("Keyboards & Mice", "CAT_PERIPH", "Ergonomic, mechanical, and wireless input accessories"),
    ("Audio & Headsets", "CAT_AUD", "Noise-cancelling headsets, desktop microphones, conference audio"),
    ("Computer Storage", "CAT_STOR", "NVMe SSDs, external backup drives, and NAS units"),
    ("Networking Equipment", "CAT_NET", "Routers, managed PoE switches, and Wi-Fi 6 access points"),
    ("Server Hardware", "CAT_SRV", "Rackmount blade servers, redundant power supplies"),
    ("Printers & Scanners", "CAT_PRINT", "Commercial laser printers, document feeders, and toner"),
    ("Power & UPS", "CAT_PWR", "Surge protectors, battery backup units, modular UPS systems"),
    ("Cables & Adapters", "CAT_CAB", "Thunderbolt 4, HDMI 2.1, USB-C hubs, and patch cords"),
    ("Office Desks & Tables", "CAT_DSK", "Motorized standing desks and collaborative conference tables"),
    ("Office Chairs", "CAT_CHR", "Ergonomic mesh chairs, executive seating, and task stools"),
    ("Storage Cabinets", "CAT_CABN", "Filing cabinets, modular lockers, and secure document safes"),
    ("Whiteboards & Easels", "CAT_WB", "Magnetic porcelain whiteboards and interactive touch panels"),
    ("Conference Hardware", "CAT_CONF", "4K teleconferencing cameras, soundbars, and beamforming mics"),
    ("Security & Access", "CAT_SEC", "Biometric badges, smart locks, and surveillance cameras"),
    ("Paper Supplies", "CAT_PPR", "Multipurpose copy paper, legal pads, and ledger paper"),
    ("Stationery & Pens", "CAT_STAT", "Gel pens, markers, staplers, sticky notes, and clips"),
    ("Breakroom & Pantry", "CAT_BRK", "Commercial espresso machines, water dispensers, and supplies"),
    ("Cleaning & Facilities", "CAT_CLN", "Sanitization stations, industrial vacuums, air purifiers"),
    ("Packaging & Shipping", "CAT_SHIP", "Corrugated boxes, thermal shipping labels, bubble wrap"),
    ("Mobile Devices", "CAT_MOB", "Enterprise smartphones, handheld barcode scanners"),
    ("Tablet Computers", "CAT_TAB", "Rugged tablets, POS touchscreen terminals, styluses"),
    ("Docks & Stations", "CAT_DCK", "Universal dual-4K docking stations and vertical stands"),
    ("Lighting & Lamps", "CAT_LGT", "Monitor light bars, LED desk lamps, conference downlights"),
    ("Toolkits & Maintenance", "CAT_TOOL", "Precision electronics screwdriver sets, cable testers"),
    ("Cooling & Fans", "CAT_FAN", "Quiet desk fans, server rack cooler units, airflow baffles"),
    ("Waste & Recycling", "CAT_WST", "Fireproof shred bins, desk side recycling containers"),
    ("Ergonomic Accessories", "CAT_ERGO", "Footrests, monitor arms, wrist cushions, laptop risers"),
    ("Visual Presentation", "CAT_PROJ", "High-lumen laser projectors and motorized ceiling screens"),
    ("Software Media & Kits", "CAT_SFT", "Operating system recovery kits, security hardware tokens"),
]


def init_and_seed_db():
    print(f"Initializing SQLite database at: {DB_PATH}")
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

    rng = random.Random(RANDOM_SEED)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Apply schema
    with open(SQL_PATH, "r", encoding="utf-8") as f:
        schema_sql = f.read()

    cursor.executescript(schema_sql)

    # -------------------------------------------------------------
    # 1. Regions (6 rows)
    # -------------------------------------------------------------
    cursor.executemany(
        "INSERT INTO regions (region_id, region_name, code) VALUES (?, ?, ?);",
        [(i + 1, r[0], r[1]) for i, r in enumerate(REGIONS_DATA)]
    )

    # -------------------------------------------------------------
    # 2. Countries (30 rows)
    # -------------------------------------------------------------
    cursor.executemany(
        "INSERT INTO countries (country_id, country_name, country_code, region_id) VALUES (?, ?, ?, ?);",
        [(i + 1, c[0], c[1], c[2]) for i, c in enumerate(COUNTRIES_DATA)]
    )

    # -------------------------------------------------------------
    # 3. Departments (12 rows)
    # -------------------------------------------------------------
    dept_rows = []
    for i, d in enumerate(DEPARTMENTS_DATA):
        dept_id = i + 1
        dept_rows.append((dept_id, dept_id, d[0], d[1], d[2], d[3]))
    cursor.executemany(
        "INSERT INTO departments (id, department_id, dept_name, department_code, budget, location) VALUES (?, ?, ?, ?, ?, ?);",
        dept_rows
    )

    # -------------------------------------------------------------
    # 4. Employees & Managers (220 employees, 24 managers)
    # -------------------------------------------------------------
    # Guarantee John Doe, Jane Reyes, Michael Brown, Emily Davis at IDs 1..4 for 100% backward compat
    job_titles = [
        "Software Engineer", "Senior Software Engineer", "Staff Engineer", "Engineering Manager",
        "DevOps Engineer", "Data Analyst", "Database Administrator", "Account Executive",
        "Sales Representative", "Sales Director", "Marketing Specialist", "Content Strategist",
        "HR Coordinator", "Talent Acquisition Lead", "Financial Analyst", "Accountant",
        "Logistics Coordinator", "Warehouse Supervisor", "Product Manager", "QA Engineer",
        "Support Specialist", "Systems Administrator", "Solutions Architect", "Compliance Officer"
    ]

    base_employees = [
        (1, 1, "John", "Doe", "john.doe@enterprise.com", 1, None, "Staff Software Engineer", 85000.0, "2021-01-15", "ACTIVE"),
        (2, 2, "Jane", "Reyes", "jane.reyes@enterprise.com", 1, None, "Director of Engineering", 95000.0, "2020-03-20", "ACTIVE"),
        (3, 3, "Michael", "Brown", "michael.brown@enterprise.com", 2, None, "Senior Sales Manager", 65000.0, "2021-06-01", "ACTIVE"),
        (4, 4, "Emily", "Davis", "emily.davis@enterprise.com", 3, None, "Marketing Manager", 60000.0, "2021-09-10", "ACTIVE"),
    ]

    # Generate 216 additional employees
    all_employees = list(base_employees)
    start_date = date(2018, 1, 1)

    cursor.execute("PRAGMA foreign_keys = OFF;")

    for emp_id in range(5, 225):
        fn = rng.choice(FIRST_NAMES)
        ln = rng.choice(LAST_NAMES)
        email = f"{fn.lower()}.{ln.lower()}{emp_id}@enterprise.com"
        dept_id = rng.randint(1, len(DEPARTMENTS_DATA))
        # Manager is assigned to one of the first 24 employees
        mgr_id = rng.randint(1, 24)
        title = rng.choice(job_titles)
        salary = round(rng.uniform(45000.0, 160000.0), 2)
        hire_d = start_date + timedelta(days=rng.randint(0, 2200))
        all_employees.append((
            emp_id, emp_id, fn, ln, email, dept_id, mgr_id, title, salary, str(hire_d), "ACTIVE"
        ))

    # Link manager_id of initial base employees (Jane Reyes mgr_id=None since she is director)
    all_employees[0] = (1, 1, "John", "Doe", "john.doe@enterprise.com", 1, 2, "Staff Software Engineer", 85000.0, "2021-01-15", "ACTIVE")
    all_employees[1] = (2, 2, "Jane", "Reyes", "jane.reyes@enterprise.com", 1, None, "Director of Engineering", 95000.0, "2020-03-20", "ACTIVE")
    all_employees[2] = (3, 3, "Michael", "Brown", "michael.brown@enterprise.com", 2, None, "Senior Sales Director", 65000.0, "2021-06-01", "ACTIVE")
    all_employees[3] = (4, 4, "Emily", "Davis", "emily.davis@enterprise.com", 3, None, "Marketing Director", 60000.0, "2021-09-10", "ACTIVE")

    cursor.executemany(
        """
        INSERT INTO employees (id, employee_id, first_name, last_name, email, department_id, manager_id, job_title, salary, hire_date, employment_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """,
        all_employees
    )

    # Managers table (24 managers across the 12 departments)
    manager_rows = []
    levels = ["VP", "DIRECTOR", "SENIOR_MANAGER", "LEAD"]
    for m_idx in range(1, 25):
        emp_id = m_idx  # First 24 employees serve as managers
        dept_id = ((m_idx - 1) % len(DEPARTMENTS_DATA)) + 1
        level = levels[(m_idx - 1) % len(levels)]
        bonus = round(rng.uniform(10.0, 25.0), 1)
        app_date = str(date(2020, 1, 1) + timedelta(days=rng.randint(0, 1000)))
        manager_rows.append((m_idx, emp_id, dept_id, level, bonus, app_date))

    cursor.executemany(
        "INSERT INTO managers (manager_id, employee_id, department_id, management_level, bonus_percentage, appointed_date) VALUES (?, ?, ?, ?, ?, ?);",
        manager_rows
    )

    # -------------------------------------------------------------
    # 5. Projects (110 rows) & Employee Projects (350+ rows)
    # -------------------------------------------------------------
    project_rows = []
    proj_prefixes = ["Apollo", "Titan", "Phoenix", "Nexus", "Vanguard", "Polaris", "Atlas", "Omega", "Helix", "Orion", "Quantum", "Apex"]
    proj_suffixes = ["Migration", "Optimization", "Redesign", "Platform", "Expansion", "Automation", "Security", "Analytics", "Core", "Modernization"]
    
    for p_id in range(1, 111):
        p_name = f"Project {rng.choice(proj_prefixes)} {rng.choice(proj_suffixes)} {p_id}"
        d_id = rng.randint(1, len(DEPARTMENTS_DATA))
        p_start = date(2022, 1, 1) + timedelta(days=rng.randint(0, 800))
        p_end = p_start + timedelta(days=rng.randint(90, 500))
        p_budget = round(rng.uniform(50000.0, 750000.0), 2)
        p_status = rng.choice(["ACTIVE", "COMPLETED", "IN_PROGRESS", "PLANNED"])
        project_rows.append((p_id, p_name, d_id, str(p_start), str(p_end), p_budget, p_status))

    cursor.executemany(
        "INSERT INTO projects (project_id, project_name, department_id, start_date, end_date, budget, status) VALUES (?, ?, ?, ?, ?, ?, ?);",
        project_rows
    )

    emp_proj_rows = []
    assign_id = 1
    roles = ["Tech Lead", "Core Developer", "QA Specialist", "Project Manager", "Scrum Master", "Business Analyst", "Architect"]
    for p_id in range(1, 111):
        # 3 to 6 employees per project
        assigned_emps = rng.sample(range(1, 225), rng.randint(3, 6))
        for emp_id in assigned_emps:
            role = rng.choice(roles)
            ass_date = str(date(2022, 6, 1) + timedelta(days=rng.randint(0, 600)))
            hours = float(rng.choice([10, 20, 30, 40]))
            emp_proj_rows.append((assign_id, emp_id, p_id, role, ass_date, hours))
            assign_id += 1

    cursor.executemany(
        "INSERT INTO employee_projects (assignment_id, employee_id, project_id, role, assigned_date, hours_allocated) VALUES (?, ?, ?, ?, ?, ?);",
        emp_proj_rows
    )

    # -------------------------------------------------------------
    # 6. Product Categories (32 rows)
    # -------------------------------------------------------------
    cursor.executemany(
        "INSERT INTO product_categories (category_id, category_name, category_code, description) VALUES (?, ?, ?, ?);",
        [(i + 1, c[0], c[1], c[2]) for i, c in enumerate(PRODUCT_CATEGORIES_DATA)]
    )

    # -------------------------------------------------------------
    # 7. Suppliers (110 rows)
    # -------------------------------------------------------------
    supplier_adjectives = ["Global", "Apex", "Pacific", "Nordic", "Pinnacle", "Precision", "Summit", "Dynamic", "Quantum", "Direct"]
    supplier_nouns = ["Components", "Electronics", "Logistics", "Manufacturing", "Supplies", "Technologies", "Industries", "Imports", "Hardware"]
    supplier_rows = []
    
    for s_id in range(1, 111):
        s_name = f"{rng.choice(supplier_adjectives)} {rng.choice(supplier_nouns)} {s_id}"
        c_name = f"{rng.choice(FIRST_NAMES)} {rng.choice(LAST_NAMES)}"
        s_email = f"supply{s_id}@{s_name.lower().replace(' ', '')[:15]}.com"
        s_phone = f"+1-{rng.randint(200,999)}-{rng.randint(100,999)}-{rng.randint(1000,9999)}"
        c_id = rng.randint(1, len(COUNTRIES_DATA))
        rating = round(rng.uniform(3.5, 5.0), 2)
        supplier_rows.append((s_id, s_name, c_name, s_email, s_phone, c_id, rating, "ACTIVE"))

    cursor.executemany(
        "INSERT INTO suppliers (supplier_id, supplier_name, contact_name, email, phone, country_id, rating, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?);",
        supplier_rows
    )

    # -------------------------------------------------------------
    # 8. Products (520+ rows)
    # -------------------------------------------------------------
    # Ensure original 5 products exist at IDs 1..5 with expected values
    base_products = [
        (1, 1, "Laptop Pro 15", "Electronics", 1, 1, 1299.99, 900.00, 50, "IN_STOCK", "SKU-PRO-15-001"),
        (2, 2, "Wireless Mouse", "Accessories", 4, 2, 29.99, 12.50, 200, "IN_STOCK", "SKU-W-MOU-002"),
        (3, 3, "Mechanical Keyboard", "Accessories", 4, 3, 89.99, 45.00, 120, "IN_STOCK", "SKU-M-KEY-003"),
        (4, 4, "4K Monitor 27in", "Electronics", 3, 1, 399.99, 260.00, 40, "IN_STOCK", "SKU-4K-MON-004"),
        (5, 5, "USB-C Hub", "Accessories", 11, 4, 49.99, 20.00, 150, "IN_STOCK", "SKU-USBC-HUB-005"),
    ]

    all_products = list(base_products)
    product_adjectives = ["Ultra", "Pro", "Enterprise", "Ergonomic", "Compact", "Precision", "Wireless", "Studio", "Rugged", "Eco", "Smart", "Flex"]
    item_types = [
        "Workstation", "Monitor", "Headset", "Keyboard", "Dock", "Scanner", "Printer",
        "Switch", "Router", "Desk", "Chair", "Cabinet", "Drive", "Webcam", "Microphone",
        "Cable Pack", "Power Hub", "Battery Backup", "Stands", "Cooler", "Speakerphone"
    ]

    for prod_id in range(6, 526):
        cat_id = rng.randint(1, len(PRODUCT_CATEGORIES_DATA))
        cat_name = PRODUCT_CATEGORIES_DATA[cat_id - 1][0]
        supp_id = rng.randint(1, len(supplier_rows))
        p_name = f"{rng.choice(product_adjectives)} {rng.choice(item_types)} {prod_id}"
        u_price = round(rng.uniform(15.0, 1999.0), 2)
        cost_price = round(u_price * rng.uniform(0.5, 0.75), 2)
        qty = rng.randint(10, 500)
        sku = f"SKU-{cat_id:02d}-{prod_id:04d}"
        status = "IN_STOCK" if qty > 20 else ("LOW_STOCK" if qty > 0 else "OUT_OF_STOCK")
        all_products.append((
            prod_id, prod_id, p_name, cat_name, cat_id, supp_id, u_price, cost_price, qty, status, sku
        ))

    cursor.executemany(
        """
        INSERT INTO products (id, product_id, product_name, category, category_id, supplier_id, unit_price, cost_price, stock_quantity, stock_status, sku)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """,
        all_products
    )

    # -------------------------------------------------------------
    # 9. Warehouses (22 rows) & Inventory (3,500+ rows)
    # -------------------------------------------------------------
    warehouse_cities = [
        ("Chicago Hub 1", 1, "Chicago", 150000.0),
        ("Dallas Regional DC", 1, "Dallas", 200000.0),
        ("Secaucus East DC", 1, "Secaucus", 120000.0),
        ("Ontario West DC", 1, "Ontario", 180000.0),
        ("Toronto Metro Hub", 2, "Toronto", 90000.0),
        ("London Gateway Hub", 4, "London", 110000.0),
        ("Frankfurt Rhine Center", 5, "Frankfurt", 160000.0),
        ("Paris North Logistics", 6, "Paris", 105000.0),
        ("Amsterdam Europort DC", 7, "Amsterdam", 140000.0),
        ("Tokyo Bay DC", 13, "Tokyo", 130000.0),
        ("Seoul Incheon Center", 14, "Incheon", 95000.0),
        ("Shanghai Pudong DC", 15, "Shanghai", 220000.0),
        ("Mumbai Central Logistics", 16, "Mumbai", 115000.0),
        ("Singapore Jurong Hub", 17, "Singapore", 85000.0),
        ("Sydney Botany DC", 28, "Sydney", 100000.0),
        ("Melbourne South DC", 28, "Melbourne", 90000.0),
        ("Dubai Logistics City", 24, "Dubai", 125000.0),
        ("Sao Paulo Hub", 20, "Sao Paulo", 110000.0),
        ("Berlin Brand Center", 5, "Berlin", 95000.0),
        ("Madrid Logistics Central", 10, "Madrid", 80000.0),
        ("Stockholm Nordic DC", 9, "Stockholm", 75000.0),
        ("Atlanta Southeast DC", 1, "Atlanta", 145000.0),
    ]

    cursor.executemany(
        "INSERT INTO warehouses (warehouse_id, warehouse_name, country_id, city, capacity_sqft, is_active) VALUES (?, ?, ?, ?, ?, 1);",
        [(i + 1, w[0], w[1], w[2], w[3]) for i, w in enumerate(warehouse_cities)]
    )

    # Populate inventory: cross warehouses with products
    inventory_rows = []
    inv_id = 1
    # Distribute each of the 525 products across 6-10 warehouses
    for prod_id in range(1, len(all_products) + 1):
        chosen_warehouses = rng.sample(range(1, len(warehouse_cities) + 1), rng.randint(6, 10))
        for wh_id in chosen_warehouses:
            qty_hand = rng.randint(0, 150)
            reorder_lvl = rng.randint(10, 25)
            reorder_qty = rng.randint(30, 100)
            inventory_rows.append((inv_id, wh_id, prod_id, qty_hand, reorder_lvl, reorder_qty))
            inv_id += 1

    cursor.executemany(
        "INSERT INTO inventory (inventory_id, warehouse_id, product_id, quantity_on_hand, reorder_level, reorder_quantity) VALUES (?, ?, ?, ?, ?, ?);",
        inventory_rows
    )

    # -------------------------------------------------------------
    # 10. Customers (1,100+ rows) & Customer Addresses (1,650+ rows)
    # -------------------------------------------------------------
    # Ensure original 4 customers are preserved with exact IDs and values
    base_customers = [
        (1, 1, "Alice Johnson", "Alice", "Johnson", "alice@example.com", "USA", 1, "ACTIVE", "2022-01-10", "2022-01-10 10:00:00"),
        (2, 2, "Bob Smith", "Bob", "Smith", "bob@example.com", "UK", 4, "ACTIVE", "2022-02-15", "2022-02-15 11:30:00"),
        (3, 3, "Charlie Lee", "Charlie", "Lee", "charlie@example.com", "Canada", 2, "ACTIVE", "2022-03-20", "2022-03-20 14:15:00"),
        (4, 4, "Diana Prince", "Diana", "Prince", "diana@example.com", "Germany", 5, "ACTIVE", "2022-04-05", "2022-04-05 09:45:00"),
    ]

    all_customers = list(base_customers)
    country_lookup = {c[0]: (i + 1, c[1]) for i, c in enumerate(COUNTRIES_DATA)}

    for cust_id in range(5, 1105):
        fn = rng.choice(FIRST_NAMES)
        ln = rng.choice(LAST_NAMES)
        full_name = f"{fn} {ln}"
        email = f"{fn.lower()}.{ln.lower()}{cust_id}@custmail.com"
        c_entry = rng.choice(COUNTRIES_DATA)
        c_name = c_entry[0]
        c_id = [i + 1 for i, c in enumerate(COUNTRIES_DATA) if c[0] == c_name][0]
        # For compatibility with queries checking country='USA', ensure ~40% USA
        if rng.random() < 0.38:
            c_name = "USA"
            c_id = 1
        reg_d = date(2021, 1, 1) + timedelta(days=rng.randint(0, 1200))
        reg_ts = f"{reg_d} {rng.randint(8,19):02d}:{rng.randint(0,59):02d}:00"
        status = rng.choices(["ACTIVE", "INACTIVE", "VIP"], weights=[80, 10, 10])[0]
        all_customers.append((
            cust_id, cust_id, full_name, fn, ln, email, c_name, c_id, status, str(reg_d), reg_ts
        ))

    cursor.executemany(
        """
        INSERT INTO customers (id, customer_id, name, first_name, last_name, email, country, country_id, customer_status, registration_date, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """,
        all_customers
    )

    # Customer Addresses (1,650+ addresses)
    address_rows = []
    addr_id = 1
    street_names = ["Main St", "Oak Ave", "Pine Rd", "Maple Way", "Cedar Ln", "Highland Dr", "Broadway", "Market St", "Lakeview Blvd", "Park Ave"]
    cities_sample = ["New York", "Chicago", "San Francisco", "Austin", "Seattle", "Toronto", "London", "Munich", "Paris", "Sydney", "Tokyo"]

    for cust in all_customers:
        c_id = cust[0]
        country_foreign_id = cust[7]
        # At least 1 primary billing address
        street = f"{rng.randint(100, 9999)} {rng.choice(street_names)}"
        city = rng.choice(cities_sample)
        postal = f"{rng.randint(10000, 99999)}"
        address_rows.append((addr_id, c_id, "BILLING", street, city, "State/Region", postal, country_foreign_id, 1))
        addr_id += 1

        # ~50% have an additional shipping address
        if rng.random() < 0.50:
            ship_street = f"{rng.randint(100, 9999)} {rng.choice(street_names)} Suite {rng.randint(10,99)}"
            address_rows.append((addr_id, c_id, "SHIPPING", ship_street, city, "State/Region", postal, country_foreign_id, 0))
            addr_id += 1

    cursor.executemany(
        """
        INSERT INTO customer_addresses (address_id, customer_id, address_type, street_address, city, state_province, postal_code, country_id, is_default)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
        """,
        address_rows
    )

    # -------------------------------------------------------------
    # 11. Orders & Order Items (5,200 orders, 15,600+ items)
    # -------------------------------------------------------------
    # Preserve original 4 orders at IDs 1..4 for 100% backward compat
    base_orders = [
        (1, 1, 1, "2023-01-10 10:30:00", 1329.98, "COMPLETED", "COMPLETED", 1),
        (2, 2, 2, "2023-01-11 14:20:00", 489.98, "COMPLETED", "COMPLETED", 2),
        (3, 3, 1, "2023-01-12 16:00:00", 399.99, "PENDING", "PENDING", 1),
        (4, 4, 3, "2023-01-15 09:15:00", 89.99, "SHIPPED", "SHIPPED", 3),
    ]

    base_order_items = [
        (1, 1, 1, 1, 1, 1299.99, 1299.99, 0.0),
        (2, 2, 1, 2, 1, 29.99, 29.99, 0.0),
        (3, 3, 2, 4, 1, 399.99, 399.99, 0.0),
        (4, 4, 2, 3, 1, 89.99, 89.99, 0.0),
        (5, 5, 3, 4, 1, 399.99, 399.99, 0.0),
        (6, 6, 4, 3, 1, 89.99, 89.99, 0.0),
    ]

    # Pre-map customer address for fast reference
    cust_to_addr = {}
    for a in address_rows:
        cust_to_addr[a[1]] = a[0]

    all_orders = list(base_orders)
    all_order_items = list(base_order_items)
    
    order_item_id_counter = 7
    order_statuses = ["COMPLETED", "SHIPPED", "PENDING", "PROCESSING", "CANCELLED"]
    status_weights = [55, 25, 10, 7, 3]

    prod_price_map = {p[0]: p[6] for p in all_products}

    start_order_date = datetime(2023, 1, 1)
    
    for ord_id in range(5, 5205):
        c_id = rng.randint(1, len(all_customers))
        status = rng.choices(order_statuses, weights=status_weights)[0]
        ord_date = start_order_date + timedelta(minutes=rng.randint(0, 900000))
        ord_date_str = ord_date.strftime("%Y-%m-%d %H:%M:%S")
        ship_addr = cust_to_addr.get(c_id, 1)

        # 2 to 5 items per order
        item_count = rng.randint(2, 5)
        chosen_prods = rng.sample(range(1, len(all_products) + 1), item_count)
        
        ord_total = 0.0
        for p_id in chosen_prods:
            qty = rng.randint(1, 4)
            unit_p = prod_price_map[p_id]
            subtot = round(qty * unit_p, 2)
            ord_total += subtot
            all_order_items.append((
                order_item_id_counter, order_item_id_counter, ord_id, p_id, qty, unit_p, subtot, 0.0
            ))
            order_item_id_counter += 1

        ord_total = round(ord_total, 2)
        all_orders.append((
            ord_id, ord_id, c_id, ord_date_str, ord_total, status, status, ship_addr
        ))

    cursor.executemany(
        """
        INSERT INTO orders (id, order_id, customer_id, order_date, total_amount, status, order_status, shipping_address_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """,
        all_orders
    )

    cursor.executemany(
        """
        INSERT INTO order_items (id, order_item_id, order_id, product_id, quantity, unit_price, subtotal, discount_percentage)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """,
        all_order_items
    )

    # -------------------------------------------------------------
    # 12. Invoices (5,204 rows)
    # -------------------------------------------------------------
    invoice_rows = []
    for ord_info in all_orders:
        ord_id = ord_info[0]
        inv_total = ord_info[4]
        tax = round(inv_total * 0.08, 2)
        inv_date = ord_info[3][:10]
        due_date = str(datetime.strptime(inv_date, "%Y-%m-%d") + timedelta(days=30))[:10]
        p_status = "PAID" if ord_info[5] in ["COMPLETED", "SHIPPED"] else "UNPAID"
        inv_number = f"INV-2023-{ord_id:06d}"
        invoice_rows.append((
            ord_id, ord_id, inv_number, inv_date, due_date, inv_total, tax, p_status
        ))

    cursor.executemany(
        """
        INSERT INTO invoices (invoice_id, order_id, invoice_number, invoice_date, due_date, total_amount, tax_amount, payment_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """,
        invoice_rows
    )

    # -------------------------------------------------------------
    # 13. Payments (4,800+ rows)
    # -------------------------------------------------------------
    payment_rows = []
    pay_id = 1
    pay_methods = ["CREDIT_CARD", "BANK_TRANSFER", "PAYPAL", "CORPORATE_PURCHASE_ORDER"]
    for ord_info in all_orders:
        if ord_info[5] in ["COMPLETED", "SHIPPED"]:
            ord_id = ord_info[0]
            amt = ord_info[4]
            method = rng.choice(pay_methods)
            pref = f"PAY-REF-{ord_id:06d}-{rng.randint(1000, 9999)}"
            p_date = ord_info[3]
            payment_rows.append((
                pay_id, ord_id, ord_id, p_date, method, pref, amt, "COMPLETED"
            ))
            pay_id += 1

    cursor.executemany(
        """
        INSERT INTO payments (payment_id, order_id, invoice_id, payment_date, payment_method, payment_reference, amount, payment_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """,
        payment_rows
    )

    # -------------------------------------------------------------
    # 14. Shipments (5,100+ rows)
    # -------------------------------------------------------------
    shipment_rows = []
    carriers = ["FedEx Express", "UPS Ground", "DHL Global", "USPS Priority", "Kuehne+Nagel"]
    ship_id = 1
    for ord_info in all_orders:
        if ord_info[5] != "CANCELLED":
            ord_id = ord_info[0]
            wh_id = rng.randint(1, len(warehouse_cities))
            track_num = f"TRK-{wh_id:02d}-{ord_id:06d}-{rng.randint(100,999)}"
            carrier = rng.choice(carriers)
            status = "DELIVERED" if ord_info[5] == "COMPLETED" else ("IN_TRANSIT" if ord_info[5] == "SHIPPED" else "PROCESSING")
            ship_ts = ord_info[3]
            est_del = str(datetime.strptime(ord_info[3][:10], "%Y-%m-%d") + timedelta(days=5))[:10]
            act_del = est_del if status == "DELIVERED" else None
            shipment_rows.append((
                ship_id, ord_id, wh_id, track_num, carrier, status, ship_ts, est_del, act_del
            ))
            ship_id += 1

    cursor.executemany(
        """
        INSERT INTO shipments (shipment_id, order_id, warehouse_id, tracking_number, carrier, shipment_status, shipped_date, estimated_delivery, actual_delivery)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
        """,
        shipment_rows
    )

    # -------------------------------------------------------------
    # 15. Product Reviews (2,500+ rows)
    # -------------------------------------------------------------
    review_rows = []
    review_headlines = [
        "Excellent build quality and performance", "Good value for enterprise use",
        "Reliable product for daily workload", "Solid hardware, fast delivery",
        "Exceeded our department expectations", "Decent performance, would recommend",
        "Top-tier finish and great ergonomics", "Works flawlessly in our office"
    ]
    review_comments = [
        "Deploying this across our entire department. High reliability and very satisfied.",
        "Exactly as described in the enterprise catalog. Arrived quickly and installed without issue.",
        "Quality is top notch. We will be purchasing more units during the next quarter.",
        "Great compatibility and seamless integration with our standard dock setups."
    ]

    for rev_id in range(1, 2550):
        p_id = rng.randint(1, len(all_products))
        c_id = rng.randint(1, len(all_customers))
        rating = rng.choices([5, 4, 3, 2, 1], weights=[60, 25, 10, 3, 2])[0]
        headline = rng.choice(review_headlines)
        comment = rng.choice(review_comments)
        rev_date = str(datetime(2023, 1, 1) + timedelta(days=rng.randint(0, 700)))[:19]
        review_rows.append((
            rev_id, p_id, c_id, rating, headline, comment, 1, rev_date
        ))

    cursor.executemany(
        """
        INSERT INTO product_reviews (review_id, product_id, customer_id, rating, headline, comment, is_verified_purchase, review_date)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """,
        review_rows
    )

    cursor.execute("PRAGMA foreign_keys = ON;")
    cursor.execute("PRAGMA foreign_key_check;")
    fk_violations = cursor.fetchall()
    if fk_violations:
        raise ValueError(f"Foreign key violations detected: {fk_violations}")

    conn.commit()
    conn.close()
    print("Database seeded with sample enterprise data successfully across 20 tables.")
    print("Foreign key integrity check passed with 0 violations.")


if __name__ == "__main__":
    init_and_seed_db()
