# Enterprise Relational Database Schema & Data Dictionary

This document details the live schema design, relational model, primary/foreign key mappings, and seed scales for the **SQL Hallucination Validator for AI Assistants** (MCA Mini-Project).

---

## 1. Relational Model & Architecture Overview

The database models a comprehensive **Enterprise Sales, Customers, Employees and Operations** ecosystem consisting of **20 interconnected relational tables**.

```mermaid
erDiagram
    REGIONS ||--o{ COUNTRIES : contains
    COUNTRIES ||--o{ CUSTOMERS : resides_in
    COUNTRIES ||--o{ CUSTOMER_ADDRESSES : located_in
    COUNTRIES ||--o{ SUPPLIERS : based_in
    COUNTRIES ||--o{ WAREHOUSES : situated_in
    
    CUSTOMERS ||--o{ CUSTOMER_ADDRESSES : has
    CUSTOMERS ||--o{ ORDERS : places
    CUSTOMERS ||--o{ PRODUCT_REVIEWS : writes
    
    DEPARTMENTS ||--o{ EMPLOYEES : employs
    DEPARTMENTS ||--o{ MANAGERS : manages
    DEPARTMENTS ||--o{ PROJECTS : sponsors
    
    EMPLOYEES ||--o{ EMPLOYEES : reports_to
    EMPLOYEES ||--o{ MANAGERS : promoted_to
    EMPLOYEES ||--o{ EMPLOYEE_PROJECTS : assigned_to
    PROJECTS ||--o{ EMPLOYEE_PROJECTS : staffing
    
    PRODUCT_CATEGORIES ||--o{ PRODUCTS : categorizes
    SUPPLIERS ||--o{ PRODUCTS : supplies
    PRODUCTS ||--o{ INVENTORY : stocked_as
    WAREHOUSES ||--o{ INVENTORY : stores
    
    PRODUCTS ||--o{ ORDER_ITEMS : contains
    ORDERS ||--o{ ORDER_ITEMS : includes
    ORDERS ||--o{ INVOICES : billed_by
    ORDERS ||--o{ PAYMENTS : paid_with
    ORDERS ||--o{ SHIPMENTS : fulfilled_via
    WAREHOUSES ||--o{ SHIPMENTS : dispatched_from
    PRODUCTS ||--o{ PRODUCT_REVIEWS : reviewed_in
```

---

## 2. Table Specifications, Keys & Row Counts

| Table Name | Primary Key | Foreign Keys | Key Relationships | Seeded Count |
|---|---|---|---|---|
| `regions` | `region_id` | *None* | Geographic continental regions | 6 |
| `countries` | `country_id` | `region_id -> regions(region_id)` | Sovereign countries | 30 |
| `departments` | `id` / `department_id` | *None* | Enterprise departments (Engineering, Sales, etc.) | 12 |
| `employees` | `id` / `employee_id` | `department_id -> departments(id)`, `manager_id -> employees(id)` | Staff members, salaries, titles, hierarchy | 224 |
| `managers` | `manager_id` | `employee_id -> employees(id)`, `department_id -> departments(id)` | Appointed executive management | 24 |
| `projects` | `project_id` | `department_id -> departments(id)` | Enterprise initiatives and budgets | 110 |
| `employee_projects` | `assignment_id` | `employee_id -> employees(id)`, `project_id -> projects(project_id)` | Many-to-many staffing assignments | 493 |
| `customers` | `id` / `customer_id` | `country_id -> countries(country_id)` | Enterprise customer accounts | 1,104 |
| `customer_addresses` | `address_id` | `customer_id -> customers(id)`, `country_id -> countries(country_id)` | Billing & shipping locations | 1,664 |
| `product_categories` | `category_id` | *None* | Product classification hierarchy | 32 |
| `suppliers` | `supplier_id` | `country_id -> countries(country_id)` | Component & goods vendors | 110 |
| `products` | `id` / `product_id` | `category_id -> product_categories(category_id)`, `supplier_id -> suppliers(supplier_id)` | Catalog items, prices, SKUs | 525 |
| `warehouses` | `warehouse_id` | `country_id -> countries(country_id)` | Regional distribution centers | 22 |
| `inventory` | `inventory_id` | `warehouse_id -> warehouses(warehouse_id)`, `product_id -> products(id)` | On-hand warehouse stock levels | 4,152 |
| `orders` | `id` / `order_id` | `customer_id -> customers(id)`, `shipping_address_id -> customer_addresses(address_id)` | Customer sales orders & totals | 5,204 |
| `order_items` | `id` / `order_item_id` | `order_id -> orders(id)`, `product_id -> products(id)` | Order line items, quantities, prices | 18,146 |
| `invoices` | `invoice_id` | `order_id -> orders(id)` | Commercial billing records | 5,204 |
| `payments` | `payment_id` | `order_id -> orders(id)`, `invoice_id -> invoices(invoice_id)` | Payment transactions and methods | 4,161 |
| `shipments` | `shipment_id` | `order_id -> orders(id)`, `warehouse_id -> warehouses(warehouse_id)` | Order fulfillment & tracking | 5,057 |
| `product_reviews` | `review_id` | `product_id -> products(id)`, `customer_id -> customers(id)` | Ratings, verified feedback | 2,549 |
| **Total** | | | **20 Interconnected Tables** | **48,829 records** |

---

## 3. How Live Schema Extraction Operates

The validator does **not** rely on hard-coded schema maps. The architecture extracts schema elements dynamically at runtime:

1. **Introspection Query**:
   - For SQLite: Queries `sqlite_master` for active user tables, executes `PRAGMA table_info('{table}')` for columns/PKs, and executes `PRAGMA foreign_key_list('{table}')` for foreign keys.
   - For MySQL / PostgreSQL: Queries `information_schema.TABLES`, `information_schema.COLUMNS`, and `information_schema.KEY_COLUMN_USAGE`.
2. **Schema Footprint Extraction (`sqlglot`)**:
   - Parses the generated SQL into an Abstract Syntax Tree (AST).
   - Extracts all referenced tables, qualified/unqualified columns, JOIN keys, and virtual CTEs.
3. **Deterministic Cross-Verification**:
   - Checks if every extracted table exists in the live catalog.
   - Verifies whether every column exists in its referenced table or candidate queried tables.
   - Verifies whether JOIN conditions reference real columns on both sides of the relationship.

---

## 4. Database Reset and Initialization

To reset or re-seed the local demonstration database from scratch:

```bash
# Windows / Linux / macOS:
python database/seed_data.py
```

To verify table row counts and foreign-key integrity at any time:

```bash
python database/verify_db.py
```

---

## 5. Hallucination Testing Scenarios

### A. Valid Queries (Approved: Status = `VALID`)

1. **Multi-Table JOIN with Aggregations and Grouping:**
   ```sql
   SELECT 
       d.dept_name,
       COUNT(e.id) AS total_staff,
       AVG(e.salary) AS average_salary
   FROM departments d
   JOIN employees e ON d.id = e.department_id
   GROUP BY d.dept_name
   HAVING AVG(e.salary) > 65000
   ORDER BY AVG(e.salary) DESC;
   ```

2. **Customer Order Fulfillment Pipeline:**
   ```sql
   SELECT 
       c.name AS customer_name,
       o.order_date,
       p.product_name,
       oi.quantity,
       oi.unit_price,
       s.carrier,
       s.tracking_number
   FROM customers c
   JOIN orders o ON c.id = o.customer_id
   JOIN order_items oi ON o.id = oi.order_id
   JOIN products p ON oi.product_id = p.id
   JOIN shipments s ON o.id = s.order_id
   WHERE o.status = 'COMPLETED'
   ORDER BY o.order_date DESC
   LIMIT 10;
   ```

3. **Subquery with Date Filtering:**
   ```sql
   SELECT product_name, unit_price, stock_quantity
   FROM products
   WHERE id IN (
       SELECT oi.product_id
       FROM order_items oi
       JOIN orders o ON oi.order_id = o.id
       WHERE o.order_date >= '2023-01-01'
   );
   ```

### B. Hallucinated Queries (Blocked: Status = `BLOCKED`)

1. **Non-Existent Table:**
   ```sql
   SELECT client_name, credit_limit FROM enterprise_clients WHERE status = 'ACTIVE';
   ```
   - **Diagnostic**: `NON_EXISTENT_TABLE`
   - **Reason**: `enterprise_clients` does not exist in the database catalog.

2. **Non-Existent Column:**
   ```sql
   SELECT name, social_security_number, telephone_number FROM customers;
   ```
   - **Diagnostic**: `NON_EXISTENT_COLUMN`
   - **Reason**: `social_security_number` and `telephone_number` do not exist in `customers`.

3. **Invalid JOIN Relationship / Hallucinated Foreign Key:**
   ```sql
   SELECT o.id, e.first_name
   FROM orders o
   JOIN employees e ON o.employee_code = e.employee_id;
   ```
   - **Diagnostic**: `INVALID_JOIN_RELATIONSHIP` / `NON_EXISTENT_COLUMN`
   - **Reason**: Join key column `employee_code` does not exist in table `orders`.
