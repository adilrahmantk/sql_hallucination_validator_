# SQL Hallucination Validator for AI Assistants

A deterministic middleware framework that validates AI-generated SQL queries against live database schemas before execution, preventing silent semantic errors, incorrect data retrieval, and schema violations.

Based on the authoritative specification:
*SQL Hallucination Validator for AI Assistants (APJ Abdul Kalam Technological University MCA Project by Adil Rahman T K)*.

---

## 1. Architecture Overview

```
[ User ] ---> [ AI Assistant ]
                     | (AI-generated SQL)
                     v
+-------------------------------------------------------+
|        SQL Hallucination Validator Middleware         |
|  1. API Interface Module (Flask REST API)             |
|  2. Query Preprocessing Module (Clean & Normalize)    |
|  3. AST Parsing Module (sqlglot / AST Generation)     |
|  4. Schema Extraction Module (Tables/Cols/Joins/CTE)  |
|  5. Live Schema Validation Module                     | <---> [ Live DB Schema ]
|  6. Decision Engine Module (Approve / Block)          |       (MySQL/Postgres)
|  7. Logging Module (Audit Store D2)                   |
+-------------------------------------------------------+
                     |
         +-----------+-----------+
         |                       |
         v                       v
 [ Safe Execution ]     [ Blocked + Diagnostic ]
 [   Result Data  ]     [ Error Report for AI  ]
```

---

## 2. Seven System Modules

| Module | Description | Implementation File |
|---|---|---|
| **Module 1: API Interface** | Flask REST API routing, request validation, serialization | `src/api/routes.py`, `src/api/schemas.py` |
| **Module 2: Query Preprocessor** | Strips comments/markdown safely without corrupting string literals | `src/preprocessor/preprocessor.py` |
| **Module 3: AST Parser** | Converts SQL to AST hierarchy using `sqlglot` | `src/parser/ast_parser.py` |
| **Module 4: Schema Extractor** | Traverses AST to extract tables, columns, joins, aliases, WHERE clauses | `src/extractor/schema_extractor.py` |
| **Module 5: Live Schema Validator** | Cross-checks extracted elements against live database `information_schema` | `src/validator/schema_validator.py`, `schema_inspector.py` |
| **Module 6: Decision Engine** | Gating policy: safely executes valid queries or returns structured error reports | `src/decision/decision_engine.py` |
| **Module 7: Logging Module** | Records audit trail (status, query, hallucinations, execution time) | `src/logger/audit_logger.py` |

---

## 3. Quick Start

### Installation
```bash
pip install -r requirements.txt
```

### Initialize / Reset Enterprise Database (20 Tables, 48,000+ Records)
```bash
python database/seed_data.py
```

### Verify Schema and Foreign Keys
```bash
python database/verify_db.py
```

For complete table definitions, foreign-key relationships, and data dictionaries, see [database/SCHEMA_DOCUMENTATION.md](file:///c:/Users/USER/.gemini/antigravity/scratch/sql_hallucination_validator/database/SCHEMA_DOCUMENTATION.md).

### Start the Middleware Server
```bash
python src/app.py
```

---

## 4. REST API Reference

### `POST /api/v1/validate`
Validates query against live schema without executing it.

**Request:**
```json
{
  "sql_query": "SELECT c.name, o.total_amount FROM customers c JOIN orders o ON c.id = o.customer_id WHERE o.status = 'COMPLETED'",
  "dialect": "mysql",
  "database_config": {
    "db_type": "mysql",
    "host": "localhost",
    "port": 3306,
    "database": "enterprise_db",
    "user": "your_user",
    "password": "your_password"
  }
}
```

**Response (Valid Query):**
```json
{
  "status": "VALID",
  "is_valid": true,
  "dialect": "mysql",
  "extracted_elements": { ... },
  "hallucinations": [],
  "message": "Query passed all deterministic schema validation checks.",
  "timestamp": "2026-08-27T12:00:00Z"
}
```

**Response (Hallucination Detected - Blocked):**
```json
{
  "status": "BLOCKED",
  "is_valid": false,
  "dialect": "mysql",
  "hallucinations": [
    {
      "type": "NON_EXISTENT_COLUMN",
      "element": "customer_address",
      "table": "customers",
      "error_message": "Column 'customer_address' does not exist in table 'customers'.",
      "suggestion": "Did you mean: ['email', 'country']?"
    }
  ],
  "message": "Query execution blocked due to 1 detected schema hallucination(s) / error(s)."
}
```

---

## 5. Running the Test Suite
```bash
pytest
```
